#!/usr/bin/env python3
"""
PublicDrop — Live Price Fetcher v4  (FIXED)
────────────────────────────────────────────────────────────────────────────────
CoinGecko is the PRIMARY live price source (tiered refresh):
  Tier 1 — Top    500 coins  → every  15 min  (pages 1–2)
  Tier 2 — Top   1000 coins  → every  30 min  (pages 1–4)
  Tier 3 — Top   5000 coins  → every  60 min  (pages 1–20)
  Tier 4 — All coins (9000+) → every 120 min  (all pages)

CMC is SUPPLEMENTARY — provides extra fields merged on top of CG data:
  - change_30d, vol_change_24h, market_cap_dominance%
  - Global market stats (total_mcap, btc_dominance, eth_dominance)
  - Fallback price for any coin CG hasn't reached yet
  - CMC refreshes ALL coins every 4 hours

Merge logic (per coin):
  CG  → price, change_24h, change_1h*, change_7d*, high_24h, low_24h,
         volume_24h, market_cap                        [PRIMARY — freshest wins]
  CMC → change_30d, vol_change_24h, dominance, rank   [SUPPLEMENT — always merged]
  price_source field = "coingecko" | "cmc" (so you always know which won)

Fear & Greed → every 60 min via alternative.me (free, no key needed)
Saves: /opt/publicdrop-api/data/live.json (atomic write)

FIXES applied vs original:
  1. Thread-safe key rotation — _cmc_ki / _cg_ki now guarded by _key_lock
  2. Retry-After header parsed safely — falls back to 60 s if value is not an integer
  3. CMC worker wrapped in outer try/except — thread can never die permanently
  4. Global-metrics log line guarded against None total_mcap crash
  5. CoinGecko symbol-collision handling in _fetch_cg_pages (keeps higher-ranked entry)
────────────────────────────────────────────────────────────────────────────────
"""

import json, time, requests, threading, logging
from datetime import datetime, timezone
from pathlib import Path

# ── Logging ───────────────────────────────────────────────────────────────────
logging.basicConfig(
    level=logging.INFO,
    format="[%(asctime)s] [LIVE] %(message)s",
    datefmt="%H:%M:%S",
)
log = logging.getLogger("live")

# ── Paths ─────────────────────────────────────────────────────────────────────
DATA_DIR  = Path("/opt/publicdrop-api/data")
META_FILE = DATA_DIR / "meta.json"
LIVE_FILE = DATA_DIR / "live.json"
LIVE_TMP  = DATA_DIR / "live.tmp.json"
DATA_DIR.mkdir(parents=True, exist_ok=True)

# ── API Keys ──────────────────────────────────────────────────────────────────
CMC_KEYS = [
    "860c8511e30f4744a16dd202e922212c",   # CMC key 1  — e.g. "xxxxxxxx-xxxx-xxxx-xxxx-xxxxxxxxxxxx"
    "a54c830841354df998b66472ef70f77f",   # CMC key 2
    "a7a4fa0a34884f5ca3dacd52c86272cf",   # CMC key 3
    "0ebeb39022404ddf9e6288051dbe35f1",   # CMC key 4
]
CMC_KEYS = [k.strip() for k in CMC_KEYS if k.strip()]

CG_KEYS = [
    "CG-LbjZu7PazoBCLibGb8gppS9Q",   # CoinGecko key 1  — e.g. "CG-xxxxxxxxxxxx"
    "CG-GtoSuTR9QDb4gLMptVyRxgJX",   # CoinGecko key 2
    "CG-v55tzoZ8fazyDv3h6pcx16bm",   # CoinGecko key 3
    "CG-EWLTyE43kxtjY2rvmURz4WyV",   # CoinGecko key 4
    "CG-yy6Zixe3wVxseFr87DLHHo4Z",   # CoinGecko key 5
    "CG-vRToJB9ep8WebQWAorB64j32",   # CoinGecko key 6
    "CG-Azhz14KRRxGmQAANQzms8gFH",   # CoinGecko key 7
]
CG_KEYS = [k.strip() for k in CG_KEYS if k.strip()] or [""]

# ── Tier config ───────────────────────────────────────────────────────────────
# (name, max_pages, interval_seconds, stagger_seconds)
# max_pages=0 means fetch ALL pages until CG returns < 250 results
CG_TIERS = [
    ("CG-Tier1-Top500",    2,   900,   0),    # top  500 → every 15 min
    ("CG-Tier2-Top1000",   4,  1800,  30),    # top 1000 → every 30 min
    ("CG-Tier3-Top5000",  20,  3600,  60),    # top 5000 → every  1 hr
    ("CG-Tier4-AllCoins",  0,  7200, 120),    # all coins → every  2 hr
]

# CMC interval: 4 hours
CMC_INTERVAL = 14400

# ── Shared state ──────────────────────────────────────────────────────────────
_prices: dict = {}   # SYM → merged price dict
_market: dict = {}   # global market block
_lock     = threading.Lock()   # guards _prices and _market
_key_lock = threading.Lock()   # FIX #1: separate lock for key rotation counters
_cmc_ki   = 0
_cg_ki    = 0

_fear_greed_value:   int | None = None
_fear_greed_label:   str | None = None
_fear_greed_updated: str | None = None
_session_credits_used = 0

# ── Key rotators (FIX #1: thread-safe, use _key_lock not _lock) ───────────────
def next_cmc_key():
    global _cmc_ki
    if not CMC_KEYS:
        raise RuntimeError("No CMC API keys configured")
    with _key_lock:
        key = CMC_KEYS[_cmc_ki % len(CMC_KEYS)]
        _cmc_ki += 1
    return key

def next_cg_key():
    global _cg_ki
    with _key_lock:
        key = CG_KEYS[_cg_ki % len(CG_KEYS)]
        _cg_ki += 1
    return key

# ── HTTP session ──────────────────────────────────────────────────────────────
SESSION = requests.Session()
SESSION.headers.update({"User-Agent": "PublicDrop/4.0", "Accept": "application/json"})

def _parse_retry_after(headers, default=60) -> int:
    """FIX #2: Safely parse Retry-After header; falls back to default if it's a date string."""
    raw = headers.get("Retry-After", default)
    try:
        return int(raw)
    except (ValueError, TypeError):
        return default

def cmc_get(path, params=None, retries=3):
    key = next_cmc_key()
    for _ in range(retries):
        try:
            r = SESSION.get(
                f"https://pro-api.coinmarketcap.com{path}",
                params=params or {},
                headers={"X-CMC_PRO_API_KEY": key},
                timeout=30,
            )
            if r.status_code == 200:
                return r.json()
            elif r.status_code == 429:
                wait = _parse_retry_after(r.headers)   # FIX #2
                log.warning(f"CMC 429 — rotating key, wait {min(wait,20)}s")
                time.sleep(min(wait, 20))
                if len(CMC_KEYS) > 1:
                    key = next_cmc_key()
            elif r.status_code == 401:
                log.error("CMC 401 — invalid API key")
                return None
            else:
                log.warning(f"CMC HTTP {r.status_code} on {path}")
                time.sleep(5)
        except Exception as e:
            log.error(f"CMC error: {e}")
            time.sleep(10)
    return None

def cg_get(path, params=None, retries=3):
    key = next_cg_key()
    for _ in range(retries):
        try:
            p = dict(params or {})
            h = {}
            if key:
                p["x_cg_demo_api_key"] = key
                h["x-cg-demo-api-key"] = key
            r = SESSION.get(
                f"https://api.coingecko.com/api/v3{path}",
                params=p, headers=h, timeout=30,
            )
            if r.status_code == 200:
                return r.json()
            elif r.status_code == 429:
                wait = _parse_retry_after(r.headers)   # FIX #2
                log.warning(f"CG 429 — rotating key, wait {min(wait,20)}s")
                time.sleep(min(wait, 20))
                key = next_cg_key()
            else:
                log.warning(f"CG HTTP {r.status_code} on {path}")
                time.sleep(5)
        except Exception as e:
            log.error(f"CG error: {e}")
            time.sleep(10)
    return None

# ── Credit tracking ───────────────────────────────────────────────────────────
def _track_credits(data: dict | None, label: str = ""):
    global _session_credits_used
    if not data:
        return
    credits = (data.get("status") or {}).get("credit_count")
    if credits is not None:
        _session_credits_used += credits
        log.info(f"CMC credits — this call: {credits} | session total: {_session_credits_used} [{label}]")

# ── Helpers ───────────────────────────────────────────────────────────────────
def now_iso():
    return datetime.now(timezone.utc).isoformat()

def load_meta_symbols() -> tuple[set, set, dict]:
    """Returns (cmc_symbols, cg_only_symbols, cg_id_map {sym->cg_id})."""
    if not META_FILE.exists():
        return set(), set(), {}
    try:
        with open(META_FILE) as f:
            d = json.load(f)
        coins     = d.get("coins", {})
        cmc_syms  = {sym for sym, v in coins.items() if v.get("source") == "cmc"}
        cg_syms   = {sym for sym, v in coins.items() if v.get("source") == "coingecko"}
        cg_id_map = {sym: v["cg_id"] for sym, v in coins.items()
                     if v.get("source") == "coingecko" and v.get("cg_id")}
        return cmc_syms, cg_syms, cg_id_map
    except Exception as e:
        log.error(f"load_meta_symbols: {e}")
        return set(), set(), {}

def _build_market_block(
    total_mcap=None, total_vol=None, mcap_change=None,
    btc_dom=None, eth_dom=None, ts=None
) -> dict:
    existing = _market
    return {
        "total_market_cap_usd":  total_mcap  if total_mcap  is not None else existing.get("total_market_cap_usd"),
        "total_volume_24h_usd":  total_vol   if total_vol   is not None else existing.get("total_volume_24h_usd"),
        "market_cap_change_24h": mcap_change if mcap_change is not None else existing.get("market_cap_change_24h"),
        "btc_dominance":         btc_dom     if btc_dom     is not None else existing.get("btc_dominance"),
        "eth_dominance":         eth_dom     if eth_dom     is not None else existing.get("eth_dominance"),
        "fear_greed_value":      _fear_greed_value,
        "fear_greed_label":      _fear_greed_label,
        "fear_greed_updated":    _fear_greed_updated,
        "updated_at":            ts or now_iso(),
    }

def save():
    """Atomically write live.json."""
    with _lock:
        snap   = dict(_prices)
        market = dict(_market)
    payload = {
        "updated_at": now_iso(),
        "count":      len(snap),
        "market":     market,
        "prices":     snap,
    }
    with open(LIVE_TMP, "w") as f:
        json.dump(payload, f, separators=(",", ":"))
    LIVE_TMP.rename(LIVE_FILE)

def load_existing():
    if LIVE_FILE.exists():
        try:
            with open(LIVE_FILE) as f:
                d = json.load(f)
            with _lock:
                _prices.update(d.get("prices", {}))
                _market.update(d.get("market", {}))
            log.info(f"Loaded {len(_prices)} existing prices + market block from disk")
        except Exception as e:
            log.warning(f"Could not load existing live.json: {e}")

# ── Fear & Greed ──────────────────────────────────────────────────────────────
def _classify_fear_greed(val: int) -> str:
    if val <= 24: return "Extreme Fear"
    if val <= 44: return "Fear"
    if val <= 55: return "Neutral"
    if val <= 74: return "Greed"
    return "Extreme Greed"

def fetch_fear_greed():
    global _fear_greed_value, _fear_greed_label, _fear_greed_updated
    try:
        r = SESSION.get("https://api.alternative.me/fng/?limit=1&format=json", timeout=15)
        if r.status_code == 200:
            entry = (r.json().get("data") or [{}])[0]
            val   = entry.get("value")
            if val is not None:
                _fear_greed_value   = int(val)
                _fear_greed_label   = entry.get("value_classification") or _classify_fear_greed(int(val))
                _fear_greed_updated = now_iso()
                log.info(f"Fear & Greed: {_fear_greed_value} ({_fear_greed_label})")
                return
        log.warning(f"Fear & Greed: HTTP {r.status_code}")
    except Exception as e:
        log.warning(f"Fear & Greed error: {e}")

def fear_greed_worker():
    log.info("Fear & Greed worker started — every 60 min")
    while True:
        fetch_fear_greed()
        time.sleep(3600)

# ── CoinGecko page fetcher (shared by all tiers) ──────────────────────────────
def _fetch_cg_pages(tier_name: str, max_pages: int) -> int:
    """
    Fetch CoinGecko market pages and write prices as PRIMARY source.
    max_pages=0 → fetch all pages until CG returns fewer than 250 results.
    Returns number of coins updated.
    FIX #5: duplicate symbol handling — keeps the higher-ranked (lower rank number) entry.
    """
    ts      = now_iso()
    updated = 0
    page    = 1

    while True:
        data = cg_get("/coins/markets", {
            "vs_currency":             "usd",
            "order":                   "market_cap_desc",
            "per_page":                250,
            "page":                    page,
            "sparkline":               "false",
            "price_change_percentage": "1h,24h,7d",
        })

        if not data:
            log.warning(f"[{tier_name}] Page {page} — no data, stopping")
            break

        for c in data:
            sym = (c.get("symbol") or "").upper().strip()
            if not sym:
                continue

            cg_price = c.get("current_price")
            cg_ch24  = c.get("price_change_percentage_24h")
            cg_ch1h  = (c.get("price_change_percentage_1h_in_currency")
                        or c.get("price_change_percentage_1h"))
            cg_ch7d  = (c.get("price_change_percentage_7d_in_currency")
                        or c.get("price_change_percentage_7d"))
            cg_rank  = c.get("market_cap_rank")

            with _lock:
                ex = _prices.get(sym, {})

                # FIX #5: if we already stored this symbol from CoinGecko this cycle,
                # only overwrite if the new entry has a better (lower) rank.
                if ex.get("price_source") == "coingecko" and ex.get("cg_ts") == ts:
                    existing_rank = ex.get("rank") or 999999
                    new_rank      = cg_rank or 999999
                    if new_rank >= existing_rank:
                        continue   # keep the higher-ranked entry already stored

                _prices[sym] = {
                    # ── PRIMARY from CoinGecko ────────────────────────────────
                    "price":          cg_price,
                    "high_24h":       c.get("high_24h"),
                    "low_24h":        c.get("low_24h"),
                    "change_24h":     cg_ch24,
                    "change_1h":      cg_ch1h  if cg_ch1h is not None else ex.get("change_1h"),
                    "change_7d":      cg_ch7d  if cg_ch7d is not None else ex.get("change_7d"),
                    "volume_24h":     c.get("total_volume"),
                    "market_cap":     c.get("market_cap"),
                    "rank":           cg_rank or ex.get("rank"),
                    "price_source":   "coingecko",
                    "cg_ts":          ts,
                    # ── PRESERVED CMC supplement fields ──────────────────────
                    "change_30d":     ex.get("change_30d"),
                    "vol_change_24h": ex.get("vol_change_24h"),
                    "dominance":      ex.get("dominance"),
                    "cmc_ts":         ex.get("cmc_ts"),
                    # ── Timestamp = this update ───────────────────────────────
                    "ts":             ts,
                }
            updated += 1

        log.info(f"[{tier_name}] Page {page} — {len(data)} coins | running total: {updated}")

        if max_pages and page >= max_pages:
            break
        if len(data) < 250:
            break
        page += 1
        time.sleep(2.5)

    return updated

# ── CoinGecko tiered workers ──────────────────────────────────────────────────
def cg_tier_worker(name: str, max_pages: int, interval: int, stagger: int):
    log.info(
        f"[{name}] Ready — "
        f"pages: {'all' if max_pages == 0 else f'1–{max_pages}'} | "
        f"interval: every {interval // 60} min | "
        f"stagger: {stagger}s"
    )
    time.sleep(stagger)

    while True:
        t0 = time.time()
        log.info(f"[{name}] ── Cycle start ──")
        updated = _fetch_cg_pages(name, max_pages)
        save()
        elapsed = time.time() - t0
        wait    = max(0, interval - elapsed)
        log.info(
            f"[{name}] Cycle done — {updated} coins updated | "
            f"store: {len(_prices)} | next in {int(wait//60)}m {int(wait%60)}s"
        )
        time.sleep(wait)

# ── CMC supplementary worker — every 4 hours ─────────────────────────────────
def cmc_worker():
    """
    Runs every 4 hours. Provides:
      1. Global market block (total_mcap, BTC/ETH dominance, etc.)
      2. Supplement fields merged into existing CG prices:
         change_30d, vol_change_24h, dominance%, rank (authoritative CMC rank)
      3. Fallback full price for any coin not yet seen by CG tiers.

    FIX #3: entire cycle is wrapped in try/except so the thread never dies.
    FIX #4: global-metrics log line is guarded against None values.
    """
    log.info(f"CMC Worker started — every {CMC_INTERVAL//3600}h | supplementary + fallback")
    time.sleep(90)   # let CG tiers run first on startup

    while True:
        try:
            _cmc_cycle()
        except Exception as e:
            # FIX #3: catch any unexpected exception so the thread keeps running
            log.error(f"CMC cycle failed with unexpected error: {e} — will retry next interval")

        wait = CMC_INTERVAL
        log.info(f"CMC next in {int(wait//60)}m {int(wait%60)}s")
        time.sleep(wait)

def _cmc_cycle():
    """Single CMC fetch cycle — called inside the worker's try/except."""
    t0      = time.time()
    ts      = now_iso()
    updated = 0

    # ── Global market stats ────────────────────────────────────────────────
    total_mcap  = None
    total_vol   = None
    btc_dom     = None
    eth_dom     = None
    mcap_change = None

    gdata = cmc_get("/v1/global-metrics/quotes/latest")
    _track_credits(gdata, "global-metrics")
    if gdata and "data" in gdata:
        gd  = gdata["data"]
        usd = gd.get("quote", {}).get("USD", {})
        total_mcap  = usd.get("total_market_cap")
        total_vol   = usd.get("total_volume_24h")
        mcap_change = usd.get("total_market_cap_yesterday_percentage_change")
        btc_dom     = gd.get("btc_dominance")
        eth_dom     = gd.get("eth_dominance")

        # FIX #4: guard each field against None before formatting
        mcap_str = f"${total_mcap:,.0f}" if total_mcap is not None else "N/A"
        vol_str  = f"${total_vol:,.0f}"  if total_vol  is not None else "N/A"
        log.info(
            f"CMC Global — mcap: {mcap_str} | vol: {vol_str} | "
            f"BTC: {btc_dom}% | ETH: {eth_dom}% | "
            f"24h change: {mcap_change}%"
        )
    else:
        log.warning("CMC global metrics failed — keeping previous values")

    with _lock:
        _market.update(_build_market_block(
            total_mcap=total_mcap, total_vol=total_vol,
            mcap_change=mcap_change, btc_dom=btc_dom,
            eth_dom=eth_dom, ts=ts,
        ))

    # ── Coin listings — all coins, paginated in 2500 batches ───────────────
    start = 1
    while True:
        data = cmc_get("/v1/cryptocurrency/listings/latest", {
            "start":   start,
            "limit":   2500,
            "convert": "USD",
            "sort":    "market_cap",
        })
        if not data or "data" not in data:
            log.warning(f"CMC listings start={start} failed — stopping batch")
            break
        _track_credits(data, f"listings start={start}")

        batch = 0
        for c in data["data"]:
            sym = (c.get("symbol") or "").upper().strip()
            if not sym:
                continue
            q        = (c.get("quote") or {}).get("USD", {})
            mcap_c   = q.get("market_cap")
            dominance = None
            if total_mcap and mcap_c:
                try:
                    dominance = round(mcap_c / total_mcap * 100, 4)
                except Exception:
                    pass

            cmc_price  = q.get("price")
            cmc_ch1h   = q.get("percent_change_1h")
            cmc_ch24   = q.get("percent_change_24h")
            cmc_ch7d   = q.get("percent_change_7d")
            cmc_ch30d  = q.get("percent_change_30d")
            cmc_vol    = q.get("volume_24h")
            cmc_volchg = q.get("volume_change_24h")
            cmc_rank   = c.get("cmc_rank")

            with _lock:
                ex            = _prices.get(sym, {})
                cg_is_primary = ex.get("price_source") == "coingecko"

                if cg_is_primary:
                    # ── CG owns price — only inject CMC supplement fields ──
                    _prices[sym]["change_30d"]     = cmc_ch30d
                    _prices[sym]["vol_change_24h"] = cmc_volchg
                    _prices[sym]["dominance"]      = dominance
                    _prices[sym]["rank"]           = cmc_rank or ex.get("rank")
                    if _prices[sym].get("change_1h") is None:
                        _prices[sym]["change_1h"] = cmc_ch1h
                    if _prices[sym].get("change_7d") is None:
                        _prices[sym]["change_7d"] = cmc_ch7d
                    _prices[sym]["cmc_ts"] = ts
                else:
                    # ── CG hasn't priced this coin yet — CMC is fallback ───
                    _prices[sym] = {
                        "price":          cmc_price,
                        "high_24h":       ex.get("high_24h"),
                        "low_24h":        ex.get("low_24h"),
                        "change_1h":      cmc_ch1h,
                        "change_24h":     cmc_ch24,
                        "change_7d":      cmc_ch7d,
                        "change_30d":     cmc_ch30d,
                        "volume_24h":     cmc_vol,
                        "vol_change_24h": cmc_volchg,
                        "market_cap":     mcap_c,
                        "dominance":      dominance,
                        "rank":           cmc_rank,
                        "price_source":   "cmc",
                        "cmc_ts":         ts,
                        "cg_ts":          ex.get("cg_ts"),
                        "ts":             ts,
                    }
            batch   += 1
            updated += 1

        log.info(f"CMC start={start}: {batch} coins processed")

        if len(data["data"]) < 2500:
            break
        start += 2500
        time.sleep(2)

    save()
    elapsed = time.time() - t0
    log.info(
        f"CMC cycle done — {updated} coins | "
        f"total store: {len(_prices)} | "
        f"elapsed: {int(elapsed)}s | "
        f"session credits: {_session_credits_used}"
    )

# ── Entrypoint ────────────────────────────────────────────────────────────────
if __name__ == "__main__":
    if not CMC_KEYS:
        log.error("No CMC API keys configured — edit CMC_KEYS and restart")
        raise SystemExit(1)

    log.info("=" * 70)
    log.info("  PublicDrop Live Fetcher v4  (fixed)")
    log.info(f"  CMC keys : {len(CMC_KEYS)} | CG keys: {len(CG_KEYS)}")
    log.info("  ──────────────────────────────────────────────────────────────")
    log.info("  [PRIMARY]      CG Tier1  Top  500 coins → every  15 min")
    log.info("  [PRIMARY]      CG Tier2  Top 1000 coins → every  30 min")
    log.info("  [PRIMARY]      CG Tier3  Top 5000 coins → every   1 hr")
    log.info("  [PRIMARY]      CG Tier4  All  coins     → every   2 hr")
    log.info("  [SUPPLEMENT]   CMC       All  9000+     → every   4 hr")
    log.info("  [FREE]         Fear & Greed              → every  60 min")
    log.info("=" * 70)

    load_existing()
    fetch_fear_greed()

    # Start all 4 CG tier workers
    for (name, max_pages, interval, stagger) in CG_TIERS:
        threading.Thread(
            target=cg_tier_worker,
            args=(name, max_pages, interval, stagger),
            daemon=True,
            name=name,
        ).start()

    # Start CMC supplement worker
    threading.Thread(target=cmc_worker,        daemon=True, name="cmc").start()
    threading.Thread(target=fear_greed_worker, daemon=True, name="fng").start()

    # Heartbeat every 5 minutes
    try:
        while True:
            time.sleep(300)
            with _lock:
                fg       = _market.get("fear_greed_value", "N/A")
                btc      = _market.get("btc_dominance",    "N/A")
                cg_count = sum(1 for v in _prices.values() if v.get("price_source") == "coingecko")
                cm_count = sum(1 for v in _prices.values() if v.get("price_source") == "cmc")
            log.info(
                f"[HEARTBEAT] Total: {len(_prices)} coins | "
                f"CG-priced: {cg_count} | CMC-fallback: {cm_count} | "
                f"BTC dom: {btc}% | F&G: {fg} | "
                f"CMC credits used this session: {_session_credits_used}"
            )
    except KeyboardInterrupt:
        log.info("Shutting down")
