#!/bin/bash
# =============================================================================
#  PublicDrop — Full Deploy Script v4  (FIXED)
#  Installs: meta_fetcher.py, live_fetcher.py, publicdrop_api_server.py
#  Services:  publicdrop-meta   (monthly CMC+CG metadata + logos)
#             publicdrop-live   (CG tiered 15min–2hr | CMC 4hr | F&G 1hr)
#             publicdrop-apiv3  (gunicorn API, port 7780)
#  Run as:   sudo bash deploy_publicdrop_v4.sh
#
#  FIXES vs v3 deploy script:
#    - Updated to v4 (matches standalone Python files — 4 CMC key slots, tiered CG)
#    - All Python files embed the same bug fixes as the standalone files
#    - gunicorn replaces Flask dev server for production
#    - Thread-safe key rotation, safe Retry-After parsing, CMC worker crash-proof
#    - CoinGecko symbol collision handling in both meta + live fetchers
#    - Logo cache uses content hash instead of file size
# =============================================================================
set -e

INSTALL_DIR="/opt/publicdrop-api"
DATA_DIR="$INSTALL_DIR/data"
LOGO_DIR="$DATA_DIR/logos"
USER="opc"    # ← change to your Linux user if different
PORT=7780     # internal port (nginx proxies /APIv3/ → this)

echo "============================================================"
echo " PublicDrop v4 Deploy"
echo "============================================================"

# ── 0. Dependencies ───────────────────────────────────────────────────────────
echo "[1/7] Installing Python dependencies..."
pip3 install flask requests schedule gunicorn --break-system-packages --quiet

# ── 1. Create directories ─────────────────────────────────────────────────────
echo "[2/7] Creating directories..."
mkdir -p "$DATA_DIR" "$LOGO_DIR"
chown -R "$USER":"$USER" "$INSTALL_DIR" 2>/dev/null || true


# ── 2. Write meta_fetcher.py ──────────────────────────────────────────────────
echo "[3/7] Writing meta_fetcher.py..."
cat > "$INSTALL_DIR/meta_fetcher.py" << 'PYEOF'
#!/usr/bin/env python3
"""
PublicDrop — Meta Fetcher (monthly refresh)  (FIXED)
Fetches coin metadata + logos from CMC and CoinGecko.
CMC coins are primary; CoinGecko fills gaps (no overlap).
Saves: /opt/publicdrop-api/data/meta.json
       /opt/publicdrop-api/data/logos/<SYM>.png  (or .jpg / .svg)

FIXES applied vs original:
  1. Retry-After header parsed safely (falls back to 60 s if it's a date string)
  2. Symbol collision handling in fetch_cg_meta — keeps the higher-ranked entry,
     logs a warning (was silently overwriting before)
  3. Logo cache validates content hash, not just file size
  4. Removed unused _lock (meta fetcher is single-threaded; lock was misleading)
"""

import os, json, time, hashlib, requests, logging, schedule
from datetime import datetime, timezone
from pathlib import Path

logging.basicConfig(
    level=logging.INFO,
    format="[%(asctime)s] [META] %(message)s",
    datefmt="%H:%M:%S",
)
log = logging.getLogger("meta")

BASE_DIR  = Path("/opt/publicdrop-api")
DATA_DIR  = BASE_DIR / "data"
LOGO_DIR  = DATA_DIR / "logos"
META_FILE = DATA_DIR / "meta.json"
META_TMP  = DATA_DIR / "meta.tmp.json"

DATA_DIR.mkdir(parents=True, exist_ok=True)
LOGO_DIR.mkdir(parents=True, exist_ok=True)

CMC_KEYS = [
    "",   # CMC key 1
    "",   # CMC key 2
    "",   # CMC key 3
    "",   # CMC key 4
]
CMC_KEYS = [k.strip() for k in CMC_KEYS if k.strip()]

CG_KEYS = [
    "",   # CoinGecko key 1
    "",   # CoinGecko key 2
    "",   # CoinGecko key 3
    "",   # CoinGecko key 4
    "",   # CoinGecko key 5
    "",   # CoinGecko key 6
    "",   # CoinGecko key 7
]
CG_KEYS = [k.strip() for k in CG_KEYS if k.strip()] or [""]

_cmc_ki = 0
_cg_ki  = 0

def next_cmc_key():
    global _cmc_ki
    if not CMC_KEYS:
        raise RuntimeError("No CMC API keys configured")
    key = CMC_KEYS[_cmc_ki % len(CMC_KEYS)]
    _cmc_ki += 1
    return key

def next_cg_key():
    global _cg_ki
    key = CG_KEYS[_cg_ki % len(CG_KEYS)]
    _cg_ki += 1
    return key

SESSION = requests.Session()
SESSION.headers.update({"User-Agent": "PublicDrop/4.0", "Accept": "application/json"})

def _parse_retry_after(headers, default=60) -> int:
    raw = headers.get("Retry-After", default)
    try:
        return int(raw)
    except (ValueError, TypeError):
        return default

def cmc_get(path, params=None, retries=3):
    key = next_cmc_key()
    for attempt in range(retries):
        try:
            r = SESSION.get(
                f"https://pro-api.coinmarketcap.com{path}",
                params=params or {},
                headers={"X-CMC_PRO_API_KEY": key},
                timeout=30,
            )
            if r.status_code == 200:
                return r.json()
            elif r.status_code == 429:
                wait = _parse_retry_after(r.headers)
                log.warning(f"CMC 429 — rotating key, wait {min(wait,20)}s")
                time.sleep(min(wait, 20))
                if len(CMC_KEYS) > 1:
                    key = next_cmc_key()
            elif r.status_code == 401:
                log.error("CMC 401 — invalid key")
                break
            else:
                log.warning(f"CMC {r.status_code} on {path}")
                time.sleep(5)
        except Exception as e:
            log.error(f"CMC request error: {e}")
            time.sleep(10)
    return None

def cg_get(path, params=None, retries=3):
    key = next_cg_key()
    for attempt in range(retries):
        try:
            p = dict(params or {})
            h = {}
            if key:
                p["x_cg_demo_api_key"] = key
                h["x-cg-demo-api-key"] = key
            r = SESSION.get(
                f"https://api.coingecko.com/api/v3{path}",
                params=p, headers=h, timeout=30,
            )
            if r.status_code == 200:
                return r.json()
            elif r.status_code == 429:
                wait = _parse_retry_after(r.headers)
                log.warning(f"CG 429 — rotating key, wait {min(wait,20)}s")
                time.sleep(min(wait, 20))
                key = next_cg_key()
            else:
                log.warning(f"CG {r.status_code} on {path}")
                time.sleep(5)
        except Exception as e:
            log.error(f"CG request error: {e}")
            time.sleep(10)
    return None

def _logo_hash(path) -> str | None:
    try:
        return hashlib.md5(path.read_bytes()).hexdigest()
    except Exception:
        return None

def download_logo(symbol: str, url: str) -> bool:
    if not url:
        return False
    ext = "png"
    for e in (".svg", ".jpg", ".jpeg", ".webp"):
        if e in url.lower():
            ext = e.lstrip(".")
            break
    dest = LOGO_DIR / f"{symbol.upper()}.{ext}"
    try:
        r = SESSION.get(url, timeout=20)
        if r.status_code != 200 or len(r.content) < 100:
            return dest.exists()
        new_hash = hashlib.md5(r.content).hexdigest()
    except Exception as e:
        log.debug(f"Logo {symbol}: fetch error: {e}")
        return dest.exists()
    if dest.exists() and _logo_hash(dest) == new_hash:
        return True
    dest.write_bytes(r.content)
    return True

def fetch_cmc_meta() -> dict:
    log.info("CMC: fetching coin listing (all pages)...")
    coins = {}
    start = 1
    while True:
        data = cmc_get("/v1/cryptocurrency/listings/latest", {
            "start": start, "limit": 5000, "convert": "USD", "sort": "market_cap",
        })
        if not data or "data" not in data:
            break
        batch = data["data"]
        if not batch:
            break
        for c in batch:
            cid = c["id"]
            sym = (c.get("symbol") or "").upper().strip()
            if sym:
                coins[cid] = {
                    "cmc_id": cid, "symbol": sym, "name": c.get("name", ""),
                    "slug": c.get("slug", ""), "rank": c.get("cmc_rank"),
                    "category": None, "tags": c.get("tags", []),
                    "platform": c.get("platform"), "source": "cmc",
                }
        log.info(f"CMC listings: fetched {len(coins)} so far (start={start})")
        if len(batch) < 5000:
            break
        start += 5000
        time.sleep(2)

    if not coins:
        log.error("CMC: listing returned nothing — aborting CMC meta fetch")
        return {}

    log.info(f"CMC: fetching metadata + logos for {len(coins)} coins...")
    meta = {}
    ids = list(coins.keys())
    BATCH = 100
    for i in range(0, len(ids), BATCH):
        batch_ids = ids[i:i+BATCH]
        data = cmc_get("/v2/cryptocurrency/info", {"id": ",".join(map(str, batch_ids))})
        if not data or "data" not in data:
            log.warning(f"CMC info batch {i//BATCH+1} failed — retrying once")
            time.sleep(10)
            data = cmc_get("/v2/cryptocurrency/info", {"id": ",".join(map(str, batch_ids))})
        if not data or "data" not in data:
            log.error(f"CMC info batch {i//BATCH+1} failed after retry — skipping {len(batch_ids)} coins")
            time.sleep(5)
            continue
        for cid_str, info in data["data"].items():
            cid  = int(cid_str)
            base = coins.get(cid, {})
            sym  = (info.get("symbol") or base.get("symbol", "")).upper().strip()
            if not sym:
                continue
            logo_url   = info.get("logo", "")
            desc       = info.get("description", "")
            urls       = info.get("urls", {})
            new_rank   = base.get("rank") or 999999
            if sym in meta:
                existing_rank = meta[sym].get("rank") or 999999
                if new_rank >= existing_rank:
                    log.warning(f"CMC symbol collision: {sym} already stored (rank {existing_rank}), skipping duplicate cmc_id={cid} (rank {new_rank})")
                    continue
                log.warning(f"CMC symbol collision: {sym} — replacing rank {existing_rank} entry with higher-ranked cmc_id={cid} (rank {new_rank})")
            ok         = download_logo(sym, logo_url)
            cmc_status = info.get("is_active", 1)
            meta[sym]  = {
                **base,
                "symbol":      sym,
                "name":        info.get("name", base.get("name", "")),
                "description": desc[:500] if desc else "",
                "logo_url":    logo_url,
                "logo_cached": ok,
                "website":     (urls.get("website") or [""])[0],
                "twitter":     (urls.get("twitter") or [""])[0],
                "reddit":      (urls.get("reddit") or [""])[0],
                "explorer":    (urls.get("explorer") or [""])[0],
                "category":    info.get("category", ""),
                "tags":        info.get("tags", base.get("tags", [])),
                "source":      "cmc",
                "status":      "active" if cmc_status == 1 else "inactive",
                "fetched_at":  datetime.now(timezone.utc).isoformat(),
            }
        log.info(f"CMC meta: {len(meta)} coins enriched (batch {i//BATCH+1}/{(len(ids)+BATCH-1)//BATCH})")
        time.sleep(1.5)

    log.info(f"CMC: total {len(meta)} coins with metadata")
    return meta

def fetch_cg_meta(skip_symbols: set) -> dict:
    log.info("CoinGecko: fetching full coin list...")
    coin_list = cg_get("/coins/list", {"include_platform": "false"})
    if not coin_list:
        log.error("CoinGecko: coin list failed")
        return {}

    new_coins = [c for c in coin_list
                 if (c.get("symbol") or "").upper().strip()
                 and (c.get("symbol") or "").upper().strip() not in skip_symbols]
    log.info(f"CoinGecko: {len(coin_list)} total, {len(new_coins)} new (not in CMC)")

    meta = {}
    for i in range(0, len(new_coins), 250):
        page_coins = new_coins[i:i+250]
        ids_str    = ",".join(c["id"] for c in page_coins)
        data = cg_get("/coins/markets", {
            "vs_currency": "usd", "ids": ids_str, "order": "market_cap_desc",
            "per_page": 250, "page": 1, "sparkline": "false",
            "price_change_percentage": "24h",
        })
        if not data:
            time.sleep(5)
            continue
        for c in data:
            sym = (c.get("symbol") or "").upper().strip()
            if not sym or sym in skip_symbols:
                continue
            new_rank = c.get("market_cap_rank") or 999999
            if sym in meta:
                existing_rank = meta[sym].get("rank") or 999999
                if new_rank >= existing_rank:
                    log.warning(f"CoinGecko symbol collision: {sym} already stored (rank {existing_rank}), skipping (rank {new_rank})")
                    continue
                log.warning(f"CoinGecko symbol collision: {sym} — replacing rank {existing_rank} with rank {new_rank}")
            logo_url  = c.get("image", "")
            ok        = download_logo(sym, logo_url)
            meta[sym] = {
                "symbol": sym, "name": c.get("name", ""), "cg_id": c.get("id", ""),
                "rank": new_rank if new_rank != 999999 else None,
                "description": "", "logo_url": logo_url, "logo_cached": ok,
                "website": "", "twitter": "", "reddit": "", "explorer": "",
                "category": "", "tags": [], "source": "coingecko", "status": "active",
                "fetched_at": datetime.now(timezone.utc).isoformat(),
            }
        log.info(f"CoinGecko meta: {len(meta)} new coins (batch {i//250+1})")
        time.sleep(2.5)

    cg_ids_ranked = sorted(
        {v["cg_id"]: sym for sym, v in meta.items() if v.get("cg_id")}.items(),
        key=lambda kv: (meta[kv[1]].get("rank") or 999999),
    )[:3000]
    log.info(f"CoinGecko: enriching top {len(cg_ids_ranked)} coins with detail pages...")
    enriched = 0
    for cg_id, sym in cg_ids_ranked:
        detail = cg_get(f"/coins/{cg_id}", {
            "localization": "false", "tickers": "false", "market_data": "false",
            "community_data": "false", "developer_data": "false",
        })
        if detail:
            desc  = (detail.get("description") or {}).get("en", "")
            links = detail.get("links") or {}
            meta[sym]["description"] = desc[:500] if desc else ""
            meta[sym]["website"]     = ((links.get("homepage") or [""])[0])
            meta[sym]["twitter"]     = links.get("twitter_screen_name", "")
            meta[sym]["reddit"]      = links.get("subreddit_url", "")
            meta[sym]["explorer"]    = ((links.get("blockchain_site") or [""])[0])
            meta[sym]["category"]    = ((detail.get("categories") or [""])[0])
            enriched += 1
        time.sleep(0.3)

    log.info(f"CoinGecko: enriched {enriched} coins with details")
    return meta

def run_meta_fetch():
    log.info("=" * 60)
    log.info("Starting full metadata refresh...")
    log.info("=" * 60)
    existing = {}
    if META_FILE.exists():
        try:
            with open(META_FILE) as f:
                existing = json.load(f).get("coins", {})
            log.info(f"Loaded {len(existing)} existing coins from disk")
        except Exception as e:
            log.warning(f"Could not load existing meta: {e}")

    cmc_meta    = fetch_cmc_meta()
    cmc_symbols = set(cmc_meta.keys())
    log.info(f"CMC: {len(cmc_symbols)} coins fetched")

    cg_meta = fetch_cg_meta(skip_symbols=cmc_symbols)
    log.info(f"CoinGecko: {len(cg_meta)} additional coins fetched")

    merged = {}
    merged.update(cg_meta)
    merged.update(cmc_meta)
    log.info(f"Total unique coins: {len(merged)}")

    payload = {
        "updated_at": datetime.now(timezone.utc).isoformat(),
        "count": len(merged), "cmc_count": len(cmc_meta), "cg_count": len(cg_meta),
        "coins": merged,
    }
    with open(META_TMP, "w") as f:
        json.dump(payload, f, separators=(",", ":"))
    META_TMP.rename(META_FILE)
    log.info(f"Saved meta.json — {len(merged)} coins (CMC: {len(cmc_meta)}, CG-only: {len(cg_meta)})")

if __name__ == "__main__":
    if not CMC_KEYS:
        log.error("No CMC API keys configured — edit CMC_KEYS in this file and restart")
        raise SystemExit(1)
    log.info("PublicDrop Meta Fetcher v4 — monthly refresh, CMC + CoinGecko")
    run_meta_fetch()
    schedule.every(30).days.do(run_meta_fetch)
    while True:
        schedule.run_pending()
        time.sleep(3600)
PYEOF


# ── 3. Write live_fetcher.py ──────────────────────────────────────────────────
echo "[4/7] Writing live_fetcher.py..."
cat > "$INSTALL_DIR/live_fetcher.py" << 'PYEOF'
#!/usr/bin/env python3
"""
PublicDrop — Live Price Fetcher v4  (FIXED)
CoinGecko tiered PRIMARY source + CMC supplementary.

FIXES vs original:
  1. Thread-safe key rotation (_key_lock separate from _lock)
  2. Safe Retry-After header parsing
  3. CMC worker wrapped in try/except — never dies permanently
  4. Global-metrics log guarded against None values
  5. CoinGecko symbol collision handling (keeps higher-ranked entry)
"""

import json, time, requests, threading, logging
from datetime import datetime, timezone
from pathlib import Path

logging.basicConfig(
    level=logging.INFO,
    format="[%(asctime)s] [LIVE] %(message)s",
    datefmt="%H:%M:%S",
)
log = logging.getLogger("live")

DATA_DIR  = Path("/opt/publicdrop-api/data")
META_FILE = DATA_DIR / "meta.json"
LIVE_FILE = DATA_DIR / "live.json"
LIVE_TMP  = DATA_DIR / "live.tmp.json"
DATA_DIR.mkdir(parents=True, exist_ok=True)

CMC_KEYS = [
    "",   # CMC key 1
    "",   # CMC key 2
    "",   # CMC key 3
    "",   # CMC key 4
]
CMC_KEYS = [k.strip() for k in CMC_KEYS if k.strip()]

CG_KEYS = [
    "",   # CoinGecko key 1
    "",   # CoinGecko key 2
    "",   # CoinGecko key 3
    "",   # CoinGecko key 4
    "",   # CoinGecko key 5
    "",   # CoinGecko key 6
    "",   # CoinGecko key 7
]
CG_KEYS = [k.strip() for k in CG_KEYS if k.strip()] or [""]

CG_TIERS = [
    ("CG-Tier1-Top500",    2,   900,   0),
    ("CG-Tier2-Top1000",   4,  1800,  30),
    ("CG-Tier3-Top5000",  20,  3600,  60),
    ("CG-Tier4-AllCoins",  0,  7200, 120),
]
CMC_INTERVAL = 14400

_prices: dict = {}
_market: dict = {}
_lock     = threading.Lock()
_key_lock = threading.Lock()   # FIX #1
_cmc_ki   = 0
_cg_ki    = 0

_fear_greed_value:   int | None = None
_fear_greed_label:   str | None = None
_fear_greed_updated: str | None = None
_session_credits_used = 0

def next_cmc_key():
    global _cmc_ki
    if not CMC_KEYS:
        raise RuntimeError("No CMC API keys configured")
    with _key_lock:
        key = CMC_KEYS[_cmc_ki % len(CMC_KEYS)]
        _cmc_ki += 1
    return key

def next_cg_key():
    global _cg_ki
    with _key_lock:
        key = CG_KEYS[_cg_ki % len(CG_KEYS)]
        _cg_ki += 1
    return key

SESSION = requests.Session()
SESSION.headers.update({"User-Agent": "PublicDrop/4.0", "Accept": "application/json"})

def _parse_retry_after(headers, default=60) -> int:
    raw = headers.get("Retry-After", default)
    try:
        return int(raw)
    except (ValueError, TypeError):
        return default

def cmc_get(path, params=None, retries=3):
    key = next_cmc_key()
    for _ in range(retries):
        try:
            r = SESSION.get(
                f"https://pro-api.coinmarketcap.com{path}",
                params=params or {}, headers={"X-CMC_PRO_API_KEY": key}, timeout=30,
            )
            if r.status_code == 200:
                return r.json()
            elif r.status_code == 429:
                wait = _parse_retry_after(r.headers)
                log.warning(f"CMC 429 — rotating key, wait {min(wait,20)}s")
                time.sleep(min(wait, 20))
                if len(CMC_KEYS) > 1:
                    key = next_cmc_key()
            elif r.status_code == 401:
                log.error("CMC 401 — invalid API key")
                return None
            else:
                log.warning(f"CMC HTTP {r.status_code} on {path}")
                time.sleep(5)
        except Exception as e:
            log.error(f"CMC error: {e}")
            time.sleep(10)
    return None

def cg_get(path, params=None, retries=3):
    key = next_cg_key()
    for _ in range(retries):
        try:
            p = dict(params or {})
            h = {}
            if key:
                p["x_cg_demo_api_key"] = key
                h["x-cg-demo-api-key"] = key
            r = SESSION.get(
                f"https://api.coingecko.com/api/v3{path}",
                params=p, headers=h, timeout=30,
            )
            if r.status_code == 200:
                return r.json()
            elif r.status_code == 429:
                wait = _parse_retry_after(r.headers)
                log.warning(f"CG 429 — rotating key, wait {min(wait,20)}s")
                time.sleep(min(wait, 20))
                key = next_cg_key()
            else:
                log.warning(f"CG HTTP {r.status_code} on {path}")
                time.sleep(5)
        except Exception as e:
            log.error(f"CG error: {e}")
            time.sleep(10)
    return None

def _track_credits(data: dict | None, label: str = ""):
    global _session_credits_used
    if not data:
        return
    credits = (data.get("status") or {}).get("credit_count")
    if credits is not None:
        _session_credits_used += credits
        log.info(f"CMC credits — this call: {credits} | session total: {_session_credits_used} [{label}]")

def now_iso():
    return datetime.now(timezone.utc).isoformat()

def load_meta_symbols() -> tuple[set, set, dict]:
    if not META_FILE.exists():
        return set(), set(), {}
    try:
        with open(META_FILE) as f:
            d = json.load(f)
        coins = d.get("coins", {})
        cmc_syms  = {sym for sym, v in coins.items() if v.get("source") == "cmc"}
        cg_syms   = {sym for sym, v in coins.items() if v.get("source") == "coingecko"}
        cg_id_map = {sym: v["cg_id"] for sym, v in coins.items()
                     if v.get("source") == "coingecko" and v.get("cg_id")}
        return cmc_syms, cg_syms, cg_id_map
    except Exception as e:
        log.error(f"load_meta_symbols: {e}")
        return set(), set(), {}

def _build_market_block(total_mcap=None, total_vol=None, mcap_change=None,
                        btc_dom=None, eth_dom=None, ts=None) -> dict:
    existing = _market
    return {
        "total_market_cap_usd":  total_mcap  if total_mcap  is not None else existing.get("total_market_cap_usd"),
        "total_volume_24h_usd":  total_vol   if total_vol   is not None else existing.get("total_volume_24h_usd"),
        "market_cap_change_24h": mcap_change if mcap_change is not None else existing.get("market_cap_change_24h"),
        "btc_dominance":         btc_dom     if btc_dom     is not None else existing.get("btc_dominance"),
        "eth_dominance":         eth_dom     if eth_dom     is not None else existing.get("eth_dominance"),
        "fear_greed_value":      _fear_greed_value,
        "fear_greed_label":      _fear_greed_label,
        "fear_greed_updated":    _fear_greed_updated,
        "updated_at":            ts or now_iso(),
    }

def save():
    with _lock:
        snap   = dict(_prices)
        market = dict(_market)
    payload = {"updated_at": now_iso(), "count": len(snap), "market": market, "prices": snap}
    with open(LIVE_TMP, "w") as f:
        json.dump(payload, f, separators=(",", ":"))
    LIVE_TMP.rename(LIVE_FILE)

def load_existing():
    if LIVE_FILE.exists():
        try:
            with open(LIVE_FILE) as f:
                d = json.load(f)
            with _lock:
                _prices.update(d.get("prices", {}))
                _market.update(d.get("market", {}))
            log.info(f"Loaded {len(_prices)} existing prices + market block from disk")
        except Exception as e:
            log.warning(f"Could not load existing live.json: {e}")

def _classify_fear_greed(val: int) -> str:
    if val <= 24: return "Extreme Fear"
    if val <= 44: return "Fear"
    if val <= 55: return "Neutral"
    if val <= 74: return "Greed"
    return "Extreme Greed"

def fetch_fear_greed():
    global _fear_greed_value, _fear_greed_label, _fear_greed_updated
    try:
        r = SESSION.get("https://api.alternative.me/fng/?limit=1&format=json", timeout=15)
        if r.status_code == 200:
            entry = (r.json().get("data") or [{}])[0]
            val   = entry.get("value")
            if val is not None:
                _fear_greed_value   = int(val)
                _fear_greed_label   = entry.get("value_classification") or _classify_fear_greed(int(val))
                _fear_greed_updated = now_iso()
                log.info(f"Fear & Greed: {_fear_greed_value} ({_fear_greed_label})")
                return
        log.warning(f"Fear & Greed: HTTP {r.status_code}")
    except Exception as e:
        log.warning(f"Fear & Greed error: {e}")

def fear_greed_worker():
    log.info("Fear & Greed worker started — every 60 min")
    while True:
        fetch_fear_greed()
        time.sleep(3600)

def _fetch_cg_pages(tier_name: str, max_pages: int) -> int:
    ts      = now_iso()
    updated = 0
    page    = 1
    while True:
        data = cg_get("/coins/markets", {
            "vs_currency": "usd", "order": "market_cap_desc",
            "per_page": 250, "page": page, "sparkline": "false",
            "price_change_percentage": "1h,24h,7d",
        })
        if not data:
            log.warning(f"[{tier_name}] Page {page} — no data, stopping")
            break
        for c in data:
            sym = (c.get("symbol") or "").upper().strip()
            if not sym:
                continue
            cg_price = c.get("current_price")
            cg_ch24  = c.get("price_change_percentage_24h")
            cg_ch1h  = (c.get("price_change_percentage_1h_in_currency") or c.get("price_change_percentage_1h"))
            cg_ch7d  = (c.get("price_change_percentage_7d_in_currency") or c.get("price_change_percentage_7d"))
            cg_rank  = c.get("market_cap_rank")
            with _lock:
                ex = _prices.get(sym, {})
                # FIX #5: keep higher-ranked entry if same symbol seen twice this cycle
                if ex.get("price_source") == "coingecko" and ex.get("cg_ts") == ts:
                    if (cg_rank or 999999) >= (ex.get("rank") or 999999):
                        continue
                _prices[sym] = {
                    "price":          cg_price,
                    "high_24h":       c.get("high_24h"),
                    "low_24h":        c.get("low_24h"),
                    "change_24h":     cg_ch24,
                    "change_1h":      cg_ch1h  if cg_ch1h is not None else ex.get("change_1h"),
                    "change_7d":      cg_ch7d  if cg_ch7d is not None else ex.get("change_7d"),
                    "volume_24h":     c.get("total_volume"),
                    "market_cap":     c.get("market_cap"),
                    "rank":           cg_rank or ex.get("rank"),
                    "price_source":   "coingecko",
                    "cg_ts":          ts,
                    "change_30d":     ex.get("change_30d"),
                    "vol_change_24h": ex.get("vol_change_24h"),
                    "dominance":      ex.get("dominance"),
                    "cmc_ts":         ex.get("cmc_ts"),
                    "ts":             ts,
                }
            updated += 1
        log.info(f"[{tier_name}] Page {page} — {len(data)} coins | running total: {updated}")
        if max_pages and page >= max_pages:
            break
        if len(data) < 250:
            break
        page += 1
        time.sleep(2.5)
    return updated

def cg_tier_worker(name: str, max_pages: int, interval: int, stagger: int):
    log.info(f"[{name}] Ready — pages: {'all' if max_pages == 0 else f'1-{max_pages}'} | interval: every {interval // 60} min | stagger: {stagger}s")
    time.sleep(stagger)
    while True:
        t0 = time.time()
        log.info(f"[{name}] -- Cycle start --")
        updated = _fetch_cg_pages(name, max_pages)
        save()
        wait = max(0, interval - (time.time() - t0))
        log.info(f"[{name}] Cycle done — {updated} coins | store: {len(_prices)} | next in {int(wait//60)}m {int(wait%60)}s")
        time.sleep(wait)

def cmc_worker():
    log.info(f"CMC Worker started — every {CMC_INTERVAL//3600}h | supplementary + fallback")
    time.sleep(90)
    while True:
        try:
            _cmc_cycle()
        except Exception as e:
            log.error(f"CMC cycle failed with unexpected error: {e} — will retry next interval")
        log.info(f"CMC next in {CMC_INTERVAL//60}m")
        time.sleep(CMC_INTERVAL)

def _cmc_cycle():
    t0      = time.time()
    ts      = now_iso()
    updated = 0

    total_mcap = total_vol = btc_dom = eth_dom = mcap_change = None
    gdata = cmc_get("/v1/global-metrics/quotes/latest")
    _track_credits(gdata, "global-metrics")
    if gdata and "data" in gdata:
        gd  = gdata["data"]
        usd = gd.get("quote", {}).get("USD", {})
        total_mcap  = usd.get("total_market_cap")
        total_vol   = usd.get("total_volume_24h")
        mcap_change = usd.get("total_market_cap_yesterday_percentage_change")
        btc_dom     = gd.get("btc_dominance")
        eth_dom     = gd.get("eth_dominance")
        # FIX #4: guard against None before formatting
        mcap_str = f"${total_mcap:,.0f}" if total_mcap is not None else "N/A"
        vol_str  = f"${total_vol:,.0f}"  if total_vol  is not None else "N/A"
        log.info(f"CMC Global — mcap: {mcap_str} | vol: {vol_str} | BTC: {btc_dom}% | ETH: {eth_dom}% | 24h change: {mcap_change}%")
    else:
        log.warning("CMC global metrics failed — keeping previous values")

    with _lock:
        _market.update(_build_market_block(
            total_mcap=total_mcap, total_vol=total_vol, mcap_change=mcap_change,
            btc_dom=btc_dom, eth_dom=eth_dom, ts=ts,
        ))

    start = 1
    while True:
        data = cmc_get("/v1/cryptocurrency/listings/latest", {
            "start": start, "limit": 2500, "convert": "USD", "sort": "market_cap",
        })
        if not data or "data" not in data:
            log.warning(f"CMC listings start={start} failed — stopping batch")
            break
        _track_credits(data, f"listings start={start}")

        batch = 0
        for c in data["data"]:
            sym = (c.get("symbol") or "").upper().strip()
            if not sym:
                continue
            q         = (c.get("quote") or {}).get("USD", {})
            mcap_c    = q.get("market_cap")
            dominance = None
            if total_mcap and mcap_c:
                try:
                    dominance = round(mcap_c / total_mcap * 100, 4)
                except Exception:
                    pass
            cmc_price  = q.get("price")
            cmc_ch1h   = q.get("percent_change_1h")
            cmc_ch24   = q.get("percent_change_24h")
            cmc_ch7d   = q.get("percent_change_7d")
            cmc_ch30d  = q.get("percent_change_30d")
            cmc_vol    = q.get("volume_24h")
            cmc_volchg = q.get("volume_change_24h")
            cmc_rank   = c.get("cmc_rank")
            with _lock:
                ex            = _prices.get(sym, {})
                cg_is_primary = ex.get("price_source") == "coingecko"
                if cg_is_primary:
                    _prices[sym]["change_30d"]     = cmc_ch30d
                    _prices[sym]["vol_change_24h"] = cmc_volchg
                    _prices[sym]["dominance"]      = dominance
                    _prices[sym]["rank"]           = cmc_rank or ex.get("rank")
                    if _prices[sym].get("change_1h") is None:
                        _prices[sym]["change_1h"] = cmc_ch1h
                    if _prices[sym].get("change_7d") is None:
                        _prices[sym]["change_7d"] = cmc_ch7d
                    _prices[sym]["cmc_ts"] = ts
                else:
                    _prices[sym] = {
                        "price": cmc_price, "high_24h": ex.get("high_24h"),
                        "low_24h": ex.get("low_24h"), "change_1h": cmc_ch1h,
                        "change_24h": cmc_ch24, "change_7d": cmc_ch7d, "change_30d": cmc_ch30d,
                        "volume_24h": cmc_vol, "vol_change_24h": cmc_volchg, "market_cap": mcap_c,
                        "dominance": dominance, "rank": cmc_rank, "price_source": "cmc",
                        "cmc_ts": ts, "cg_ts": ex.get("cg_ts"), "ts": ts,
                    }
            batch   += 1
            updated += 1
        log.info(f"CMC start={start}: {batch} coins processed")
        if len(data["data"]) < 2500:
            break
        start += 2500
        time.sleep(2)

    save()
    log.info(f"CMC cycle done — {updated} coins | total store: {len(_prices)} | elapsed: {int(time.time()-t0)}s | session credits: {_session_credits_used}")

if __name__ == "__main__":
    if not CMC_KEYS:
        log.error("No CMC API keys configured — edit CMC_KEYS and restart")
        raise SystemExit(1)

    log.info("=" * 70)
    log.info("  PublicDrop Live Fetcher v4  (fixed)")
    log.info(f"  CMC keys: {len(CMC_KEYS)} | CG keys: {len(CG_KEYS)}")
    log.info("  [PRIMARY]    CG Tier1  Top  500 coins → every  15 min")
    log.info("  [PRIMARY]    CG Tier2  Top 1000 coins → every  30 min")
    log.info("  [PRIMARY]    CG Tier3  Top 5000 coins → every   1 hr")
    log.info("  [PRIMARY]    CG Tier4  All  coins     → every   2 hr")
    log.info("  [SUPPLEMENT] CMC       All  9000+     → every   4 hr")
    log.info("  [FREE]       Fear & Greed              → every  60 min")
    log.info("=" * 70)

    load_existing()
    fetch_fear_greed()

    for (name, max_pages, interval, stagger) in CG_TIERS:
        threading.Thread(target=cg_tier_worker, args=(name, max_pages, interval, stagger),
                         daemon=True, name=name).start()

    threading.Thread(target=cmc_worker,        daemon=True, name="cmc").start()
    threading.Thread(target=fear_greed_worker, daemon=True, name="fng").start()

    try:
        while True:
            time.sleep(300)
            with _lock:
                fg       = _market.get("fear_greed_value", "N/A")
                btc      = _market.get("btc_dominance",    "N/A")
                cg_count = sum(1 for v in _prices.values() if v.get("price_source") == "coingecko")
                cm_count = sum(1 for v in _prices.values() if v.get("price_source") == "cmc")
            log.info(f"[HEARTBEAT] Total: {len(_prices)} | CG: {cg_count} | CMC: {cm_count} | BTC: {btc}% | F&G: {fg} | Credits: {_session_credits_used}")
    except KeyboardInterrupt:
        log.info("Shutting down")
PYEOF


# ── 4. Write publicdrop_api_server.py ─────────────────────────────────────────
echo "[5/7] Writing publicdrop_api_server.py..."
cat > "$INSTALL_DIR/publicdrop_api_server.py" << 'PYEOF'
#!/usr/bin/env python3
"""
PublicDrop — API Server (standalone, port 7780)
For production: gunicorn -w 4 -b 127.0.0.1:7780 publicdrop_api_server:app
"""

import json, time, logging
from datetime import datetime, timezone
from pathlib import Path
from flask import Flask, jsonify, request, send_file, abort

DATA_DIR  = Path("/opt/publicdrop-api/data")
LOGO_DIR  = DATA_DIR / "logos"
META_FILE = DATA_DIR / "meta.json"
LIVE_FILE = DATA_DIR / "live.json"
PAGE_SIZE = 100
PORT      = 7780

logging.basicConfig(level=logging.INFO, format="[%(asctime)s] [API] %(message)s", datefmt="%H:%M:%S")
log = logging.getLogger("api")
app = Flask(__name__)

_meta: dict = {}
_live: dict = {}
_meta_mtime = 0.0
_live_mtime = 0.0
_sorted_coins: list = []
_cats_index: dict = {}
_meta_icon_count: int = 0
_meta_processing: int = 0
_market_stats: dict = {}

def _load_meta():
    global _meta, _meta_mtime, _sorted_coins, _cats_index, _meta_icon_count, _meta_processing
    try:
        mtime = META_FILE.stat().st_mtime
        if mtime != _meta_mtime:
            with open(META_FILE) as f:
                d = json.load(f)
            _meta = d.get("coins", {})
            _meta_mtime = mtime
            _sorted_coins = sorted(_meta.keys(), key=lambda s: (_meta[s].get("rank") or 999999))
            _cats_index = {}
            for sym, v in _meta.items():
                cat = (v.get("category") or "").lower().strip()
                for tag in (v.get("tags") or []):
                    t = (tag or "").lower().strip()
                    if t:
                        _cats_index.setdefault(t, []).append(sym)
                if cat:
                    _cats_index.setdefault(cat, []).append(sym)
            _meta_icon_count = sum(
                1 for sym in _meta
                if any((LOGO_DIR / f"{sym}.{ext}").exists() for ext in ("png", "jpg", "jpeg", "svg", "webp"))
            )
            _meta_processing = sum(
                1 for v in _meta.values() if (v.get("status") or "active").lower() in ("inactive", "processing")
            )
            log.info(f"Reloaded meta.json — {len(_meta)} coins, {_meta_icon_count} icons")
    except FileNotFoundError:
        pass
    except Exception as e:
        log.error(f"load_meta: {e}")

def _load_live():
    global _live, _live_mtime, _market_stats
    try:
        mtime = LIVE_FILE.stat().st_mtime
        if mtime != _live_mtime:
            with open(LIVE_FILE) as f:
                d = json.load(f)
            _live = d.get("prices", {})
            _market_stats = d.get("market", {})
            _live_mtime = mtime
    except FileNotFoundError:
        pass
    except Exception as e:
        log.error(f"load_live: {e}")

_last_refresh = 0.0
def _refresh():
    global _last_refresh
    now = time.time()
    if now - _last_refresh < 5.0:
        return
    _last_refresh = now
    _load_meta()
    _load_live()

_STALE_SECS = 20 * 60

def _price_age_secs(ts):
    if not ts:
        return None
    try:
        dt = datetime.fromisoformat(ts.replace("Z", "+00:00"))
        return max(0, int((datetime.now(timezone.utc) - dt).total_seconds()))
    except Exception:
        return None

def _is_stale(ts):
    age = _price_age_secs(ts)
    return (age is None) or (age > _STALE_SECS)

def _build_coin(sym: str) -> dict | None:
    sym  = sym.upper().strip()
    meta = _meta.get(sym)
    if not meta:
        return None
    live = _live.get(sym, {})
    logo_path = None
    for ext in ("png", "jpg", "jpeg", "svg", "webp"):
        if (LOGO_DIR / f"{sym}.{ext}").exists():
            logo_path = f"/APIv3/logo?sym={sym}"
            break
    return {
        "symbol": sym, "name": meta.get("name", ""),
        "rank": live.get("rank") or meta.get("rank"),
        "source": meta.get("source", ""), "cmc_id": meta.get("cmc_id"), "cg_id": meta.get("cg_id"),
        "description": meta.get("description", ""), "category": meta.get("category", ""),
        "tags": meta.get("tags", []), "website": meta.get("website", ""),
        "twitter": meta.get("twitter", ""), "reddit": meta.get("reddit", ""),
        "explorer": meta.get("explorer", ""), "logo_url": meta.get("logo_url", ""), "logo": logo_path,
        "price_usd": live.get("price"), "change_1h": live.get("change_1h"),
        "change_24h": live.get("change_24h"), "change_7d": live.get("change_7d"),
        "change_30d": live.get("change_30d"), "high_24h": live.get("high_24h"),
        "low_24h": live.get("low_24h"), "volume_24h": live.get("volume_24h"),
        "vol_change_24h": live.get("vol_change_24h"), "market_cap": live.get("market_cap"),
        "dominance": live.get("dominance"), "price_source": live.get("price_source"),
        "price_updated_at": live.get("ts"), "price_age_secs": _price_age_secs(live.get("ts")),
        "is_stale": _is_stale(live.get("ts")),
    }

def _sym_from_query(q: str) -> str | None:
    q = (q or "").strip()
    if not q:
        return None
    up = q.upper()
    if up in _meta:
        return up
    ql = q.lower()
    for sym, v in _meta.items():
        if v.get("name", "").lower() == ql or v.get("slug", "").lower() == ql or v.get("cg_id", "").lower() == ql:
            return sym
    return None

def _cors(resp):
    resp.headers["Access-Control-Allow-Origin"] = "*"
    return resp

@app.route("/APIv3/ping")
def ping():
    return _cors(jsonify({"ok": True, "ts": datetime.now(timezone.utc).isoformat()}))

@app.route("/APIv3/status")
def status():
    _refresh()
    market_data_ts = datetime.fromtimestamp(_live_mtime, tz=timezone.utc).isoformat() if _live_mtime else None
    ms = _market_stats
    gainers = losers = neutral = 0
    for lv in _live.values():
        ch = lv.get("change_24h")
        if ch is None: neutral += 1
        elif ch > 0:   gainers += 1
        elif ch < 0:   losers  += 1
        else:          neutral += 1
    total_coins = len(_meta)
    processing  = _meta_processing
    return _cors(jsonify({
        "status": "running", "total_coins": total_coins,
        "Coin Listed": total_coins - processing, "Coin Processing": processing,
        "Coin_Icon": _meta_icon_count,
        "total_market_cap_usd": ms.get("total_market_cap_usd"),
        "total_volume_24h_usd": ms.get("total_volume_24h_usd"),
        "market_cap_change_24h": ms.get("market_cap_change_24h"),
        "btc_dominance": ms.get("btc_dominance"), "eth_dominance": ms.get("eth_dominance"),
        "fear_greed_value": ms.get("fear_greed_value"), "fear_greed_label": ms.get("fear_greed_label"),
        "gainers": gainers, "losers": losers, "neutral": neutral,
        "cache_size": len(_live), "market_data_updated": market_data_ts,
    }))

@app.route("/APIv3/details")
def details():
    _refresh()
    q   = request.args.get("sym", "").strip()
    sym = _sym_from_query(q)
    if not sym:
        return _cors(jsonify({"error": f"Coin not found: {q}"})), 404
    coin = _build_coin(sym)
    if not coin:
        return _cors(jsonify({"error": f"No data for {sym}"})), 404
    return _cors(jsonify(coin))

@app.route("/APIv3/logo")
def logo():
    _refresh()
    q   = request.args.get("sym", "").strip().upper()
    sym = _sym_from_query(q) or q
    for ext in ("png", "jpg", "jpeg", "svg", "webp"):
        p = LOGO_DIR / f"{sym}.{ext}"
        if p.exists():
            mime = "image/svg+xml" if ext == "svg" else f"image/{ext}"
            resp = send_file(p, mimetype=mime)
            resp.headers["Cache-Control"] = "public, max-age=86400"
            return resp
    url = _meta.get(sym, {}).get("logo_url")
    if url:
        return _cors(jsonify({"redirect": url}))
    abort(404)

@app.route("/APIv3/coins")
def coins():
    _refresh()
    try:
        page = max(1, int(request.args.get("page", 1)))
    except ValueError:
        page = 1
    source_filter = (request.args.get("source") or "").strip().lower()
    sort_by = (request.args.get("sort") or "rank").strip().lower()
    if sort_by not in {"rank", "price", "volume", "change_24h", "market_cap"}:
        sort_by = "rank"
    pool = [s for s in _sorted_coins if _meta.get(s, {}).get("source") == source_filter] \
           if source_filter in ("cmc", "coingecko") else list(_sorted_coins)
    if sort_by != "rank":
        SORT_KEY = {
            "price":      lambda s: ((_live.get(s) or {}).get("price")     or 0),
            "volume":     lambda s: ((_live.get(s) or {}).get("volume_24h") or 0),
            "change_24h": lambda s: ((_live.get(s) or {}).get("change_24h") or 0),
            "market_cap": lambda s: ((_live.get(s) or {}).get("market_cap") or 0),
        }
        pool = sorted(pool, key=SORT_KEY[sort_by], reverse=True)
    start  = (page - 1) * PAGE_SIZE
    result = [c for sym in pool[start:start+PAGE_SIZE] for c in [_build_coin(sym)] if c]
    return _cors(jsonify({
        "page": page, "per_page": PAGE_SIZE, "total": len(pool),
        "pages": max(1, -(-len(pool) // PAGE_SIZE)),
        "sort": sort_by, "source": source_filter or "all", "coins": result,
    }))

@app.route("/APIv3/search")
def search():
    _refresh()
    q = (request.args.get("q") or "").strip().lower()
    if not q:
        return _cors(jsonify({"results": []}))
    results = []
    for sym in _sorted_coins:
        v = _meta.get(sym, {})
        if q in sym.lower() or q in (v.get("name") or "").lower() or q in (v.get("slug") or v.get("cg_id") or "").lower():
            c = _build_coin(sym)
            if c:
                results.append(c)
        if len(results) >= 50:
            break
    return _cors(jsonify({"query": q, "count": len(results), "results": results}))

@app.route("/APIv3/categories")
def categories():
    _refresh()
    cat = (request.args.get("cat") or "").strip().lower()
    if not cat:
        all_cats = sorted({(v.get("category") or "").lower().strip() for v in _meta.values() if v.get("category")})
        return _cors(jsonify({"categories": all_cats}))
    result = [c for sym in _cats_index.get(cat, []) for c in [_build_coin(sym)] if c]
    result.sort(key=lambda x: (x.get("rank") or 999999))
    return _cors(jsonify({"category": cat, "count": len(result), "coins": result}))

if __name__ == "__main__":
    log.info(f"PublicDrop API Server — port {PORT}")
    log.info("For production: gunicorn -w 4 -b 127.0.0.1:7780 publicdrop_api_server:app")
    app.run(host="0.0.0.0", port=PORT, threaded=True)
PYEOF


# ── 5. Systemd services ───────────────────────────────────────────────────────
echo "[6/7] Installing systemd services..."

sudo tee /etc/systemd/system/publicdrop-meta.service > /dev/null << EOF
[Unit]
Description=PublicDrop Meta Fetcher (monthly CMC + CoinGecko)
After=network-online.target
Wants=network-online.target

[Service]
Type=simple
User=$USER
WorkingDirectory=$INSTALL_DIR
ExecStart=/usr/bin/python3 $INSTALL_DIR/meta_fetcher.py
Restart=on-failure
RestartSec=60
StandardOutput=journal
StandardError=journal

[Install]
WantedBy=multi-user.target
EOF

sudo tee /etc/systemd/system/publicdrop-live.service > /dev/null << EOF
[Unit]
Description=PublicDrop Live Fetcher v4 (CG tiered + CMC supplement + Fear&Greed)
After=network-online.target publicdrop-meta.service
Wants=network-online.target

[Service]
Type=simple
User=$USER
WorkingDirectory=$INSTALL_DIR
ExecStart=/usr/bin/python3 $INSTALL_DIR/live_fetcher.py
Restart=always
RestartSec=15
StandardOutput=journal
StandardError=journal

[Install]
WantedBy=multi-user.target
EOF

sudo tee /etc/systemd/system/publicdrop-apiv3.service > /dev/null << EOF
[Unit]
Description=PublicDrop API Server v4 (gunicorn, port $PORT)
After=network.target

[Service]
Type=simple
User=$USER
WorkingDirectory=$INSTALL_DIR
ExecStart=/usr/local/bin/gunicorn -w 4 -b 127.0.0.1:$PORT publicdrop_api_server:app
Restart=always
RestartSec=5
StandardOutput=journal
StandardError=journal

[Install]
WantedBy=multi-user.target
EOF


# ── 6. Enable and start services ─────────────────────────────────────────────
echo "[7/7] Enabling and starting services..."
sudo systemctl daemon-reload
sudo systemctl enable publicdrop-meta publicdrop-live publicdrop-apiv3

echo ""
echo " Starting publicdrop-meta (first run fetches all metadata — takes ~20 min)..."
sudo systemctl restart publicdrop-meta

echo " Starting publicdrop-live..."
sudo systemctl restart publicdrop-live

echo " Starting publicdrop-apiv3..."
sudo systemctl restart publicdrop-apiv3

sleep 3

echo ""
echo "============================================================"
echo " PublicDrop v4 Deploy Complete"
echo "============================================================"
echo ""
echo " Services:"
echo "   publicdrop-meta   — monthly CMC+CG metadata + logo fetch"
echo "   publicdrop-live   — CG tiered 15min–2hr | CMC 4hr | F&G 1hr"
echo "   publicdrop-apiv3  — gunicorn API on port $PORT"
echo ""
echo " Data files:"
echo "   $DATA_DIR/meta.json    — coin metadata"
echo "   $DATA_DIR/live.json    — live prices + market block"
echo "   $DATA_DIR/logos/       — downloaded coin logos"
echo ""
echo " Nginx snippet (add inside server {} block if not present):"
echo ""
echo "   location /APIv3/ {"
echo "       proxy_pass         http://127.0.0.1:$PORT;"
echo "       proxy_set_header   Host \$host;"
echo "       proxy_set_header   X-Real-IP \$remote_addr;"
echo "       proxy_read_timeout 30s;"
echo "   }"
echo ""
echo " Monitor logs:"
echo "   sudo journalctl -u publicdrop-meta   -f"
echo "   sudo journalctl -u publicdrop-live   -f"
echo "   sudo journalctl -u publicdrop-apiv3  -f"
echo ""
echo " API endpoints:"
echo "   https://publicdrop.in/APIv3/ping"
echo "   https://publicdrop.in/APIv3/status"
echo "   https://publicdrop.in/APIv3/details?sym=BTC"
echo "   https://publicdrop.in/APIv3/coins?page=1"
echo "   https://publicdrop.in/APIv3/search?q=sol"
echo "   https://publicdrop.in/APIv3/categories?cat=defi"
echo ""
echo "━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━"
echo " IMPORTANT — Add your API keys before restarting services:"
echo "   $INSTALL_DIR/meta_fetcher.py   →  CMC_KEYS  +  CG_KEYS"
echo "   $INSTALL_DIR/live_fetcher.py   →  CMC_KEYS  +  CG_KEYS"
echo " Then run:"
echo "   sudo systemctl restart publicdrop-meta publicdrop-live"
echo "━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━"
