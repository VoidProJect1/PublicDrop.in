#!/usr/bin/env python3
"""
PublicDrop — API Server (standalone, port 7780)
Reads from meta.json + live.json written by the fetcher scripts.
Served at https://publicdrop.in/APIv3/ via existing nginx reverse proxy.

Endpoints:
  GET /APIv3/ping
  GET /APIv3/status
  GET /APIv3/details?sym=BTC
  GET /APIv3/details?sym=bitcoin
  GET /APIv3/logo?sym=BTC
  GET /APIv3/coins?page=1&sort=rank&source=cmc
  GET /APIv3/search?q=sol
  GET /APIv3/categories
  GET /APIv3/categories?cat=defi

NOTE: For production, run this behind gunicorn:
  gunicorn -w 4 -b 127.0.0.1:7780 publicdrop_api_server:app
"""

import json, time, logging
from datetime import datetime, timezone
from pathlib import Path
from flask import Flask, jsonify, request, send_file, abort

# ── Config ────────────────────────────────────────────────────────────────────
DATA_DIR  = Path("/opt/publicdrop-api/data")
LOGO_DIR  = DATA_DIR / "logos"
META_FILE = DATA_DIR / "meta.json"
LIVE_FILE = DATA_DIR / "live.json"
PAGE_SIZE = 100   # coins per page
PORT      = 7780

logging.basicConfig(
    level=logging.INFO,
    format="[%(asctime)s] [API] %(message)s",
    datefmt="%H:%M:%S",
)
log = logging.getLogger("api")

app = Flask(__name__)

# ── File cache (reload on mtime change) ──────────────────────────────────────
_meta: dict = {}
_live: dict = {}
_meta_mtime = 0.0
_live_mtime = 0.0
_sorted_coins: list = []   # rank-sorted symbol list
_cats_index: dict = {}     # category/tag -> [sym, ...]

_meta_icon_count: int = 0
_meta_processing: int = 0

def _load_meta():
    global _meta, _meta_mtime, _sorted_coins, _cats_index, _meta_icon_count, _meta_processing
    try:
        mtime = META_FILE.stat().st_mtime
        if mtime != _meta_mtime:
            with open(META_FILE) as f:
                d = json.load(f)
            _meta = d.get("coins", {})
            _meta_mtime = mtime
            _sorted_coins = sorted(
                _meta.keys(),
                key=lambda s: (_meta[s].get("rank") or 999999),
            )
            _cats_index = {}
            for sym, v in _meta.items():
                cat = (v.get("category") or "").lower().strip()
                for tag in (v.get("tags") or []):
                    t = (tag or "").lower().strip()
                    if t:
                        _cats_index.setdefault(t, []).append(sym)
                if cat:
                    _cats_index.setdefault(cat, []).append(sym)
            _meta_icon_count = sum(
                1 for sym in _meta
                if any((LOGO_DIR / f"{sym}.{ext}").exists()
                       for ext in ("png", "jpg", "jpeg", "svg", "webp"))
            )
            _meta_processing = sum(
                1 for v in _meta.values()
                if (v.get("status") or "active").lower() in ("inactive", "processing")
            )
            log.info(f"Reloaded meta.json — {len(_meta)} coins, {_meta_icon_count} icons")
    except FileNotFoundError:
        pass
    except Exception as e:
        log.error(f"load_meta: {e}")

_market_stats: dict = {}

def _load_live():
    global _live, _live_mtime, _market_stats
    try:
        mtime = LIVE_FILE.stat().st_mtime
        if mtime != _live_mtime:
            with open(LIVE_FILE) as f:
                d = json.load(f)
            _live = d.get("prices", {})
            _market_stats = d.get("market", {})
            _live_mtime = mtime
    except FileNotFoundError:
        pass
    except Exception as e:
        log.error(f"load_live: {e}")

_last_refresh = 0.0
_REFRESH_THROTTLE = 5.0

def _refresh():
    global _last_refresh
    now = time.time()
    if now - _last_refresh < _REFRESH_THROTTLE:
        return
    _last_refresh = now
    _load_meta()
    _load_live()

# ── Price helpers ─────────────────────────────────────────────────────────────
_STALE_SECS = 20 * 60   # 20 minutes

def _price_age_secs(ts: str | None) -> int | None:
    if not ts:
        return None
    try:
        dt = datetime.fromisoformat(ts.replace("Z", "+00:00"))
        return max(0, int((datetime.now(timezone.utc) - dt).total_seconds()))
    except Exception:
        return None

def _is_stale(ts: str | None) -> bool:
    age = _price_age_secs(ts)
    return (age is None) or (age > _STALE_SECS)

# ── Coin builder ──────────────────────────────────────────────────────────────
def _build_coin(sym: str) -> dict | None:
    """Merge meta + live data for a single symbol."""
    sym = sym.upper().strip()
    meta = _meta.get(sym)
    if not meta:
        return None
    live = _live.get(sym, {})

    logo_path = None
    for ext in ("png", "jpg", "jpeg", "svg", "webp"):
        p = LOGO_DIR / f"{sym}.{ext}"
        if p.exists():
            logo_path = f"/APIv3/logo?sym={sym}"
            break

    return {
        "symbol":           sym,
        "name":             meta.get("name", ""),
        "rank":             live.get("rank") or meta.get("rank"),
        "source":           meta.get("source", ""),
        "cmc_id":           meta.get("cmc_id"),
        "cg_id":            meta.get("cg_id"),
        "description":      meta.get("description", ""),
        "category":         meta.get("category", ""),
        "tags":             meta.get("tags", []),
        "website":          meta.get("website", ""),
        "twitter":          meta.get("twitter", ""),
        "reddit":           meta.get("reddit", ""),
        "explorer":         meta.get("explorer", ""),
        "logo_url":         meta.get("logo_url", ""),
        "logo":             logo_path,
        # Live fields
        "price_usd":        live.get("price"),
        "change_1h":        live.get("change_1h"),
        "change_24h":       live.get("change_24h"),
        "change_7d":        live.get("change_7d"),
        "change_30d":       live.get("change_30d"),
        "high_24h":         live.get("high_24h"),
        "low_24h":          live.get("low_24h"),
        "volume_24h":       live.get("volume_24h"),
        "vol_change_24h":   live.get("vol_change_24h"),
        "market_cap":       live.get("market_cap"),
        "dominance":        live.get("dominance"),
        "price_source":     live.get("price_source"),
        "price_updated_at": live.get("ts"),
        "price_age_secs":   _price_age_secs(live.get("ts")),
        "is_stale":         _is_stale(live.get("ts")),
    }

# ── Symbol resolver ───────────────────────────────────────────────────────────
def _sym_from_query(q: str) -> str | None:
    """Resolve BTC, bitcoin, or ethereum to uppercase symbol."""
    q = (q or "").strip()
    if not q:
        return None
    up = q.upper()
    if up in _meta:
        return up
    ql = q.lower()
    for sym, v in _meta.items():
        if (v.get("name", "").lower() == ql or
                v.get("slug", "").lower() == ql or
                v.get("cg_id", "").lower() == ql):
            return sym
    return None

# ── CORS ──────────────────────────────────────────────────────────────────────
def _cors(resp):
    resp.headers["Access-Control-Allow-Origin"] = "*"
    return resp

# ── Routes ────────────────────────────────────────────────────────────────────

@app.route("/APIv3/ping")
def ping():
    return _cors(jsonify({"ok": True, "ts": datetime.now(timezone.utc).isoformat()}))


@app.route("/APIv3/status")
def status():
    _refresh()

    market_data_ts = None
    if _live_mtime:
        market_data_ts = datetime.fromtimestamp(_live_mtime, tz=timezone.utc).isoformat()

    ms = _market_stats

    gainers = losers = neutral = 0
    for lv in _live.values():
        ch = lv.get("change_24h")
        if ch is None:
            neutral += 1
        elif ch > 0:
            gainers += 1
        elif ch < 0:
            losers += 1
        else:
            neutral += 1

    total_coins = len(_meta)
    processing  = _meta_processing
    listed      = total_coins - processing

    return _cors(jsonify({
        "status":                  "running",
        "total_coins":             total_coins,
        "Coin Listed":             listed,
        "Coin Processing":         processing,
        "Coin_Icon":               _meta_icon_count,
        "total_market_cap_usd":    ms.get("total_market_cap_usd"),
        "total_volume_24h_usd":    ms.get("total_volume_24h_usd"),
        "market_cap_change_24h":   ms.get("market_cap_change_24h"),
        "btc_dominance":           ms.get("btc_dominance"),
        "eth_dominance":           ms.get("eth_dominance"),
        "fear_greed_value":        ms.get("fear_greed_value"),
        "fear_greed_label":        ms.get("fear_greed_label"),
        "gainers":                 gainers,
        "losers":                  losers,
        "neutral":                 neutral,
        "cache_size":              len(_live),
        "market_data_updated":     market_data_ts,
    }))


@app.route("/APIv3/details")
def details():
    _refresh()
    q   = request.args.get("sym", "").strip()
    sym = _sym_from_query(q)
    if not sym:
        return _cors(jsonify({"error": f"Coin not found: {q}"})), 404
    coin = _build_coin(sym)
    if not coin:
        return _cors(jsonify({"error": f"No data for {sym}"})), 404
    return _cors(jsonify(coin))


@app.route("/APIv3/logo")
def logo():
    _refresh()
    q   = request.args.get("sym", "").strip().upper()
    sym = _sym_from_query(q) or q
    for ext in ("png", "jpg", "jpeg", "svg", "webp"):
        p = LOGO_DIR / f"{sym}.{ext}"
        if p.exists():
            mime = "image/svg+xml" if ext == "svg" else f"image/{ext}"
            resp = send_file(p, mimetype=mime)
            resp.headers["Cache-Control"] = "public, max-age=86400"
            return resp
    meta = _meta.get(sym, {})
    url  = meta.get("logo_url")
    if url:
        return _cors(jsonify({"redirect": url}))
    abort(404)


@app.route("/APIv3/coins")
def coins():
    _refresh()
    try:
        page = max(1, int(request.args.get("page", 1)))
    except ValueError:
        page = 1

    source_filter = (request.args.get("source") or "").strip().lower()
    sort_by = (request.args.get("sort") or "rank").strip().lower()
    VALID_SORTS = {"rank", "price", "volume", "change_24h", "market_cap"}
    if sort_by not in VALID_SORTS:
        sort_by = "rank"

    if source_filter in ("cmc", "coingecko"):
        pool = [s for s in _sorted_coins if _meta.get(s, {}).get("source") == source_filter]
    else:
        pool = list(_sorted_coins)

    if sort_by != "rank":
        SORT_KEY = {
            "price":      lambda s: ((_live.get(s) or {}).get("price")     or 0),
            "volume":     lambda s: ((_live.get(s) or {}).get("volume_24h") or 0),
            "change_24h": lambda s: ((_live.get(s) or {}).get("change_24h") or 0),
            "market_cap": lambda s: ((_live.get(s) or {}).get("market_cap") or 0),
        }
        pool = sorted(pool, key=SORT_KEY[sort_by], reverse=True)

    start  = (page - 1) * PAGE_SIZE
    syms   = pool[start:start + PAGE_SIZE]
    result = [c for sym in syms for c in [_build_coin(sym)] if c]

    return _cors(jsonify({
        "page":     page,
        "per_page": PAGE_SIZE,
        "total":    len(pool),
        "pages":    max(1, -(-len(pool) // PAGE_SIZE)),
        "sort":     sort_by,
        "source":   source_filter or "all",
        "coins":    result,
    }))


@app.route("/APIv3/search")
def search():
    _refresh()
    q = (request.args.get("q") or "").strip().lower()
    if len(q) < 1:
        return _cors(jsonify({"results": []}))
    results = []
    for sym in _sorted_coins:
        v    = _meta.get(sym, {})
        name = (v.get("name") or "").lower()
        slug = (v.get("slug") or v.get("cg_id") or "").lower()
        if q in sym.lower() or q in name or q in slug:
            c = _build_coin(sym)
            if c:
                results.append(c)
        if len(results) >= 50:
            break
    return _cors(jsonify({"query": q, "count": len(results), "results": results}))


@app.route("/APIv3/categories")
def categories():
    _refresh()
    cat = (request.args.get("cat") or "").strip().lower()
    if not cat:
        all_cats = sorted(set(
            (v.get("category") or "").lower().strip()
            for v in _meta.values()
            if v.get("category")
        ))
        return _cors(jsonify({"categories": all_cats}))

    syms   = _cats_index.get(cat, [])
    result = [c for sym in syms for c in [_build_coin(sym)] if c]
    result.sort(key=lambda x: (x.get("rank") or 999999))
    return _cors(jsonify({"category": cat, "count": len(result), "coins": result}))


# ── Entrypoint ────────────────────────────────────────────────────────────────
if __name__ == "__main__":
    log.info(f"PublicDrop API Server — port {PORT}")
    log.info("For production use gunicorn: gunicorn -w 4 -b 127.0.0.1:7780 publicdrop_api_server:app")
    app.run(host="0.0.0.0", port=PORT, threaded=True)
