#!/usr/bin/env python3
"""
PublicDrop — Meta Fetcher (monthly refresh)  (FIXED)
Fetches coin metadata + logos from CMC and CoinGecko.
CMC coins are primary; CoinGecko fills gaps (no overlap).
Saves: /opt/publicdrop-api/data/meta.json
       /opt/publicdrop-api/data/logos/<SYM>.png  (or .jpg / .svg)

FIXES applied vs original:
  1. Retry-After header parsed safely (falls back to 60 s if it's a date string)
  2. Symbol collision handling in fetch_cg_meta — keeps the higher-ranked entry,
     logs a warning (was silently overwriting before)
  3. Logo cache validates content hash, not just file size
  4. Removed unused _lock (meta fetcher is single-threaded; lock was misleading)
"""

import os, json, time, hashlib, requests, logging, schedule
from datetime import datetime, timezone
from pathlib import Path

# ── Logging ──────────────────────────────────────────────────────────────────
logging.basicConfig(
    level=logging.INFO,
    format="[%(asctime)s] [META] %(message)s",
    datefmt="%H:%M:%S",
)
log = logging.getLogger("meta")

# ── Paths ─────────────────────────────────────────────────────────────────────
BASE_DIR  = Path("/opt/publicdrop-api")
DATA_DIR  = BASE_DIR / "data"
LOGO_DIR  = DATA_DIR / "logos"
META_FILE = DATA_DIR / "meta.json"
META_TMP  = DATA_DIR / "meta.tmp.json"

DATA_DIR.mkdir(parents=True, exist_ok=True)
LOGO_DIR.mkdir(parents=True, exist_ok=True)

# ── API Keys ──────────────────────────────────────────────────────────────────
CMC_KEYS = [
    "",   # CMC key 1  — e.g. "xxxxxxxx-xxxx-xxxx-xxxx-xxxxxxxxxxxx"
    "",   # CMC key 2
    "",   # CMC key 3
    "",   # CMC key 4
]
CMC_KEYS = [k.strip() for k in CMC_KEYS if k.strip()]

CG_KEYS = [
    "",   # CoinGecko key 1  — e.g. "CG-xxxxxxxxxxxx"
    "",   # CoinGecko key 2
    "",   # CoinGecko key 3
    "",   # CoinGecko key 4
    "",   # CoinGecko key 5
    "",   # CoinGecko key 6
    "",   # CoinGecko key 7
]
CG_KEYS = [k.strip() for k in CG_KEYS if k.strip()] or [""]

# ── Key rotators (single-threaded — no lock needed) ───────────────────────────
_cmc_ki = 0
_cg_ki  = 0

def next_cmc_key():
    global _cmc_ki
    if not CMC_KEYS:
        raise RuntimeError("No CMC API keys configured")
    key = CMC_KEYS[_cmc_ki % len(CMC_KEYS)]
    _cmc_ki += 1
    return key

def next_cg_key():
    global _cg_ki
    key = CG_KEYS[_cg_ki % len(CG_KEYS)]
    _cg_ki += 1
    return key

# ── HTTP helpers ──────────────────────────────────────────────────────────────
SESSION = requests.Session()
SESSION.headers.update({"User-Agent": "PublicDrop/4.0", "Accept": "application/json"})

def _parse_retry_after(headers, default=60) -> int:
    """FIX #1: Safely parse Retry-After; falls back to default if it's a date string."""
    raw = headers.get("Retry-After", default)
    try:
        return int(raw)
    except (ValueError, TypeError):
        return default

def cmc_get(path, params=None, retries=3):
    """GET from CMC with key rotation on 429."""
    key = next_cmc_key()
    for attempt in range(retries):
        try:
            r = SESSION.get(
                f"https://pro-api.coinmarketcap.com{path}",
                params=params or {},
                headers={"X-CMC_PRO_API_KEY": key},
                timeout=30,
            )
            if r.status_code == 200:
                return r.json()
            elif r.status_code == 429:
                wait = _parse_retry_after(r.headers)   # FIX #1
                log.warning(f"CMC 429 — rotating key, wait {min(wait,20)}s")
                time.sleep(min(wait, 20))
                if len(CMC_KEYS) > 1:
                    key = next_cmc_key()
            elif r.status_code == 401:
                log.error("CMC 401 — invalid key")
                break
            else:
                log.warning(f"CMC {r.status_code} on {path}")
                time.sleep(5)
        except Exception as e:
            log.error(f"CMC request error: {e}")
            time.sleep(10)
    return None

def cg_get(path, params=None, retries=3):
    """GET from CoinGecko with key rotation on 429."""
    key = next_cg_key()
    for attempt in range(retries):
        try:
            p = dict(params or {})
            h = {}
            if key:
                p["x_cg_demo_api_key"] = key
                h["x-cg-demo-api-key"] = key
            r = SESSION.get(
                f"https://api.coingecko.com/api/v3{path}",
                params=p,
                headers=h,
                timeout=30,
            )
            if r.status_code == 200:
                return r.json()
            elif r.status_code == 429:
                wait = _parse_retry_after(r.headers)   # FIX #1
                log.warning(f"CG 429 — rotating key, wait {min(wait,20)}s")
                time.sleep(min(wait, 20))
                key = next_cg_key()
            else:
                log.warning(f"CG {r.status_code} on {path}")
                time.sleep(5)
        except Exception as e:
            log.error(f"CG request error: {e}")
            time.sleep(10)
    return None

# ── Logo downloader (FIX #3: real hash check, not file-size guess) ────────────
def _logo_hash(path: Path) -> str | None:
    """Return MD5 hex digest of a file, or None if it can't be read."""
    try:
        return hashlib.md5(path.read_bytes()).hexdigest()
    except Exception:
        return None

def download_logo(symbol: str, url: str) -> bool:
    """
    Download logo. Skips if already cached AND content matches (hash check).
    FIX #3: previously used file size > 2 KB as a proxy for validity;
    now we actually hash the content so stale/corrupt logos get refreshed.
    """
    if not url:
        return False
    ext = "png"
    for e in (".svg", ".jpg", ".jpeg", ".webp"):
        if e in url.lower():
            ext = e.lstrip(".")
            break
    dest = LOGO_DIR / f"{symbol.upper()}.{ext}"

    # Fetch the remote file
    try:
        r = SESSION.get(url, timeout=20)
        if r.status_code != 200 or len(r.content) < 100:
            return False
        new_hash = hashlib.md5(r.content).hexdigest()
    except Exception as e:
        log.debug(f"Logo {symbol}: fetch error: {e}")
        return dest.exists()   # keep existing if we couldn't fetch

    # Compare with cached version
    if dest.exists():
        existing_hash = _logo_hash(dest)
        if existing_hash == new_hash:
            return True   # already up to date

    dest.write_bytes(r.content)
    return True

# ── CMC metadata fetch (up to 9000 coins) ────────────────────────────────────
def fetch_cmc_meta() -> dict:
    """
    Returns dict keyed by SYMBOL (uppercase).
    Two listing calls cover all 9000+ CMC coins (limit 5000 each).
    """
    log.info("CMC: fetching coin listing (all pages)...")
    coins = {}   # cmc_id -> basic info
    start = 1
    while True:
        data = cmc_get("/v1/cryptocurrency/listings/latest", {
            "start": start, "limit": 5000,
            "convert": "USD",
            "sort": "market_cap",
        })
        if not data or "data" not in data:
            break
        batch = data["data"]
        if not batch:
            break
        for c in batch:
            cid = c["id"]
            sym = (c.get("symbol") or "").upper().strip()
            if sym:
                coins[cid] = {
                    "cmc_id":   cid,
                    "symbol":   sym,
                    "name":     c.get("name", ""),
                    "slug":     c.get("slug", ""),
                    "rank":     c.get("cmc_rank"),
                    "category": None,
                    "tags":     c.get("tags", []),
                    "platform": c.get("platform"),
                    "source":   "cmc",
                }
        log.info(f"CMC listings: fetched {len(coins)} so far (start={start})")
        if len(batch) < 5000:
            break
        start += 5000
        time.sleep(2)

    if not coins:
        log.error("CMC: listing returned nothing — aborting CMC meta fetch")
        return {}

    # Fetch metadata (logo, description, urls) in batches of 100
    log.info(f"CMC: fetching metadata + logos for {len(coins)} coins...")
    meta = {}
    ids = list(coins.keys())
    BATCH = 100
    for i in range(0, len(ids), BATCH):
        batch_ids = ids[i:i+BATCH]
        data = cmc_get("/v2/cryptocurrency/info", {"id": ",".join(map(str, batch_ids))})
        if not data or "data" not in data:
            log.warning(f"CMC info batch {i//BATCH+1} failed — retrying once")
            time.sleep(10)
            data = cmc_get("/v2/cryptocurrency/info", {"id": ",".join(map(str, batch_ids))})
        if not data or "data" not in data:
            log.error(f"CMC info batch {i//BATCH+1} failed after retry — skipping {len(batch_ids)} coins")
            time.sleep(5)
            continue
        for cid_str, info in data["data"].items():
            cid  = int(cid_str)
            base = coins.get(cid, {})
            sym  = (info.get("symbol") or base.get("symbol", "")).upper().strip()
            if not sym:
                continue
            logo_url = info.get("logo", "")
            desc     = info.get("description", "")
            urls     = info.get("urls", {})
            # Symbol collision: keep the higher-ranked coin
            new_rank = base.get("rank") or 999999
            if sym in meta:
                existing_rank = meta[sym].get("rank") or 999999
                if new_rank >= existing_rank:
                    log.warning(
                        f"CMC symbol collision: {sym} already stored (rank {existing_rank}), "
                        f"skipping duplicate cmc_id={cid} (rank {new_rank})"
                    )
                    continue
                log.warning(
                    f"CMC symbol collision: {sym} — replacing rank {existing_rank} entry "
                    f"with higher-ranked cmc_id={cid} (rank {new_rank})"
                )
            # Download logo
            ok = download_logo(sym, logo_url)
            # CMC "is_active": 1 = active, 0 = inactive/delisted
            cmc_status = info.get("is_active", 1)
            meta[sym] = {
                **base,
                "symbol":      sym,
                "name":        info.get("name", base.get("name", "")),
                "description": desc[:500] if desc else "",
                "logo_url":    logo_url,
                "logo_cached": ok,
                "website":     (urls.get("website") or [""])[0],
                "twitter":     (urls.get("twitter") or [""])[0],
                "reddit":      (urls.get("reddit") or [""])[0],
                "explorer":    (urls.get("explorer") or [""])[0],
                "category":    info.get("category", ""),
                "tags":        info.get("tags", base.get("tags", [])),
                "source":      "cmc",
                "status":      "active" if cmc_status == 1 else "inactive",
                "fetched_at":  datetime.now(timezone.utc).isoformat(),
            }
        log.info(f"CMC meta: {len(meta)} coins enriched (batch {i//BATCH+1}/{(len(ids)+BATCH-1)//BATCH})")
        time.sleep(1.5)

    log.info(f"CMC: total {len(meta)} coins with metadata")
    return meta

# ── CoinGecko coin list + metadata ───────────────────────────────────────────
def fetch_cg_meta(skip_symbols: set) -> dict:
    """
    Fetch CoinGecko metadata for coins NOT already in CMC set.
    FIX #2: symbol collisions now keep the higher-ranked entry and log a warning.
    """
    log.info("CoinGecko: fetching full coin list...")
    coin_list = cg_get("/coins/list", {"include_platform": "false"})
    if not coin_list:
        log.error("CoinGecko: coin list failed")
        return {}

    # Filter out symbols already in CMC
    new_coins = []
    for c in coin_list:
        sym = (c.get("symbol") or "").upper().strip()
        if sym and sym not in skip_symbols:
            new_coins.append(c)

    log.info(f"CoinGecko: {len(coin_list)} total, {len(new_coins)} new (not in CMC)")

    meta = {}
    for i in range(0, len(new_coins), 250):
        page_coins = new_coins[i:i+250]
        ids_str    = ",".join(c["id"] for c in page_coins)
        data = cg_get("/coins/markets", {
            "vs_currency":             "usd",
            "ids":                     ids_str,
            "order":                   "market_cap_desc",
            "per_page":                250,
            "page":                    1,
            "sparkline":               "false",
            "price_change_percentage": "24h",
        })
        if not data:
            time.sleep(5)
            continue

        for c in data:
            sym = (c.get("symbol") or "").upper().strip()
            if not sym or sym in skip_symbols:
                continue

            # FIX #2: handle CoinGecko symbol collisions (keep higher-ranked)
            new_rank = c.get("market_cap_rank") or 999999
            if sym in meta:
                existing_rank = meta[sym].get("rank") or 999999
                if new_rank >= existing_rank:
                    log.warning(
                        f"CoinGecko symbol collision: {sym} already stored "
                        f"(rank {existing_rank}), skipping duplicate (rank {new_rank})"
                    )
                    continue
                log.warning(
                    f"CoinGecko symbol collision: {sym} — replacing rank {existing_rank} "
                    f"with higher-ranked entry (rank {new_rank})"
                )

            logo_url = c.get("image", "")
            ok = download_logo(sym, logo_url)
            meta[sym] = {
                "symbol":      sym,
                "name":        c.get("name", ""),
                "cg_id":       c.get("id", ""),
                "rank":        new_rank if new_rank != 999999 else None,
                "description": "",
                "logo_url":    logo_url,
                "logo_cached": ok,
                "website":     "",
                "twitter":     "",
                "reddit":      "",
                "explorer":    "",
                "category":    "",
                "tags":        [],
                "source":      "coingecko",
                "status":      "active",
                "fetched_at":  datetime.now(timezone.utc).isoformat(),
            }

        log.info(f"CoinGecko meta: {len(meta)} new coins (batch {i//250+1})")
        time.sleep(2.5)

    # For CoinGecko-only coins, enrich with detail call (description, links)
    # Limit to top 3000 by rank to prevent 4+ hour runs
    cg_ids_all = {v["cg_id"]: sym for sym, v in meta.items() if v.get("cg_id")}
    cg_ids_ranked = sorted(
        cg_ids_all.items(),
        key=lambda kv: (meta[kv[1]].get("rank") or 999999),
    )[:3000]
    cg_ids = dict(cg_ids_ranked)
    log.info(f"CoinGecko: enriching top {len(cg_ids)} coins (by rank) with detail pages...")
    enriched = 0
    for cg_id, sym in list(cg_ids.items()):
        detail = cg_get(f"/coins/{cg_id}", {
            "localization": "false",
            "tickers": "false",
            "market_data": "false",
            "community_data": "false",
            "developer_data": "false",
        })
        if detail:
            desc  = (detail.get("description") or {}).get("en", "")
            links = detail.get("links") or {}
            meta[sym]["description"] = desc[:500] if desc else ""
            meta[sym]["website"]     = ((links.get("homepage") or [""])[0])
            meta[sym]["twitter"]     = links.get("twitter_screen_name", "")
            meta[sym]["reddit"]      = links.get("subreddit_url", "")
            meta[sym]["explorer"]    = ((links.get("blockchain_site") or [""])[0])
            meta[sym]["category"]    = ((detail.get("categories") or [""])[0])
            enriched += 1
        time.sleep(0.3)   # 7 keys → 210 calls/min is safe

    log.info(f"CoinGecko: enriched {enriched} coins with details")
    return meta

# ── Main monthly job ──────────────────────────────────────────────────────────
def run_meta_fetch():
    log.info("=" * 60)
    log.info("Starting full metadata refresh...")
    log.info("=" * 60)

    # Load existing data to avoid redundant logo downloads
    existing = {}
    if META_FILE.exists():
        try:
            with open(META_FILE) as f:
                existing = json.load(f).get("coins", {})
            log.info(f"Loaded {len(existing)} existing coins from disk")
        except Exception as e:
            log.warning(f"Could not load existing meta: {e}")

    # 1. Fetch CMC metadata
    cmc_meta = fetch_cmc_meta()
    cmc_symbols = set(cmc_meta.keys())
    log.info(f"CMC: {len(cmc_symbols)} coins fetched")

    # 2. Fetch CoinGecko metadata for non-CMC coins
    cg_meta = fetch_cg_meta(skip_symbols=cmc_symbols)
    log.info(f"CoinGecko: {len(cg_meta)} additional coins fetched")

    # 3. Merge (CMC wins, no overwrites)
    merged = {}
    merged.update(cg_meta)   # CoinGecko base
    merged.update(cmc_meta)  # CMC overwrites (higher priority)

    log.info(f"Total unique coins: {len(merged)}")

    # 4. Save
    payload = {
        "updated_at": datetime.now(timezone.utc).isoformat(),
        "count":      len(merged),
        "cmc_count":  len(cmc_meta),
        "cg_count":   len(cg_meta),
        "coins":      merged,
    }
    with open(META_TMP, "w") as f:
        json.dump(payload, f, separators=(",", ":"))
    META_TMP.rename(META_FILE)
    log.info(f"Saved meta.json — {len(merged)} coins (CMC: {len(cmc_meta)}, CG-only: {len(cg_meta)})")

# ── Entrypoint ────────────────────────────────────────────────────────────────
if __name__ == "__main__":
    if not CMC_KEYS:
        log.error("No CMC API keys configured — edit CMC_KEYS in this file and restart")
        raise SystemExit(1)
    log.info("PublicDrop Meta Fetcher — monthly refresh, CMC + CoinGecko  (fixed)")
    run_meta_fetch()       # Run immediately on start

    # Schedule monthly (every 30 days)
    schedule.every(30).days.do(run_meta_fetch)
    while True:
        schedule.run_pending()
        time.sleep(3600)
